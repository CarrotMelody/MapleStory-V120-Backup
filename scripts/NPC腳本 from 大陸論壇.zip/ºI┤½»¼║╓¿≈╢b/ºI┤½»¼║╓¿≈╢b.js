// 楓之島版權所有 92fzd.com
//兌換祝福卷軸
importPackage(net.sf.odinms.client);
var status = 0;



function start() {
    status = -1;
    action(1, 0, 0);
}


function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
    } else {
        if (status >= 2 && mode == 0) {
            cm.sendOk("什麼？");
            cm.dispose();
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;
        if (status == 0) {
                cm.sendNext("偉大的安拉女神需要5張卷軸碎片製作 #b祝福卷軸#k .");
            }
        else if (status == 1) {
            if ((cm.haveItem(4001136, 5)) && 

(cm.haveItem(2050003)) && (cm.getMeso() >= 100000)) {
            cm.sendYesNo("一道光，顯現出女神的模樣.女神心靈感應對你說：是否合成 #b祝福卷軸#k ？");
            }
            else if (!cm.haveItem(4001136, 5)) {
            cm.sendOk("祝福卷軸需要 5 張 #b卷軸碎片#k 的力量才能夠合成 .");
            cm.dispose();
            }
            else if (!cm.haveItem(2050003)) {
            cm.sendOk("5張卷軸碎片之後還需要1瓶聖水作為製作 #b祝福卷軸#k 藥引.");
            cm.dispose();
            }
            else if (!cm.getMeso() <= 100000) {
            cm.sendOk("你還需要 #b100000金幣#k 作為製作卷軸的費用.");
            cm.dispose();
            }
            
        }
        else if (status == 2) {
            cm.LaBaNotice("一道光 "+cm.getplayername()+" 玩家在女神的庇佑下成功合成了 祝福卷軸 。"); //你們的端可能沒有這個函數，建議去掉。
            cm.gainMeso(-100000);
            cm.gainItem(4001136, -5);
            cm.gainItem(2050003, -1);
            cm.gainItem(2340000, 1);
            
}
}
}