var status = 0;
var price = 20000000;
var map = Array(240010501);

function start() {
status = -1;
action(1, 0, 0);
}

function action(mode, type, selection) {
if (mode == -1) {
cm.dispose();
} else {
if (mode == 0 && status == 0) {
cm.dispose();
return;
}
if (mode == 1)
status++;
else
status--;
if (status == 0) {
cm.sendSimple("你好! 歡迎你來到扎昆祭台 !你想要進去挑戰#b扎昆#k嗎 ? 如果你想要挑戰他, 你需要有#b火焰的眼#k, 才能召喚出扎昆,並且需要等級達到150級 .rn#L0##b購買一個#b火焰的眼需要1,000,000金幣#krn#L1##b進入扎昆祭台.#l");
} else if (status == 1) {
if (selection == 0) {
if(cm.getMeso() >= 10000000) {
cm.gainMeso(-10000000);
cm.gainItem(4001017, 1);
cm.sendOk("購買成功!");
} else {
cm.sendOk("金幣不足.");
}
cm.dispose();
} else if (status == 2) {
} else if (selection == 1 && cm.getLevel() >= 150) {
if (cm.getC().getChannel() >=3 && cm.getC().getChannel() < 5)
{
cm.warp(280030000, 0);
cm.dispose();
}
else
{
cm.sendOk("扎昆大怪物只在能在4頻道被召喚.");
mode = 1;
status = -1;
cm.dispose();
}

}
else{
cm.sendOk("你必須達到150級以上才能挑戰#b扎昆#k.");
mode = 1;
status = -1;
cm.dispose();
}
}
}
}
您正在看的文章來自92MS冒險島私服研究中心 http://www.92ms.cn,原文地址:http://www.92ms.cn/read.php?tid=93