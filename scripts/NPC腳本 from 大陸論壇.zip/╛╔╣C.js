importPackage(java.util);
importPackage(net.sf.odinms.client);
importPackage(net.sf.odinms.server);

function start() {
        status = -1;
        
        action(1, 0, 0);
}

function action(mode, type, selection) {
            if (mode == -1) {
                cm.dispose();
            }
            else {
                if (status >= 0 && mode == 0) {
                        cm.sendOk("#e好的,如果你想好了要做什麼,我會很樂意的為你服務的..");
                        cm.dispose();
                        return;                    
                }
                if (mode == 1) {
                        status++;
                }
                else {
                        status--;
                }
                        if (status == 0) {
            var item = cm.getChar().getInventory(MapleInventoryType.EQUIP).getNextFreeSlot();
            var use = cm.getChar().getInventory(MapleInventoryType.USE).getNextFreeSlot();
            var etc = cm.getChar().getInventory(MapleInventoryType.ETC).getNextFreeSlot();
            var cash = cm.getChar().getInventory(MapleInventoryType.CASH).getNextFreeSlot();
                        cm.sendSimple("#eHi，本服的東西大降價!我是#r妞B冒險島#k超級NPC，為你提供最優質的服務。\r\n #d#L1#銅板會員#l     #r#L2#金銀會員#l     #g#L3#寶石貴賓#l \r\n\r\n#e#L9#【轉生排行榜】#l          #L10#【家族排行榜】#l\r\n#L16#【財富排行榜】#l          #k#L15#【人氣排行榜】#l\r\n#k#L12#【宰殺排行榜】#l          #L13#【等級排行榜】#l\r\n#L6#【被殺排行榜】#k#l          #L14#【GM名單】#l\r\n#L26#【我的信息】#rNEW!#k#l     #L11#【遊戲守則】#l");
                        } else if (status == 1) {
                        if (selection == 1) {
                                   if(cm.getChar().getVip() >= 1) {
                   cm.warp(209000000, 0);
                   cm.sendOk("尊敬的銅板會員，我已經將你傳送至#r銅板會員地圖-幸福村#n#k了.歡迎再次光臨!"); 
                                   cm.dispose();
                                   }else{
                   cm.sendOk("#b你不是銅板，請聯繫GM給你在線開通!");
                   cm.dispose();   }  
                        } else if  (selection == 2) {
                                   if(cm.getChar().getVip() >= 2) {
                   cm.warp(922020300, 0);
cm.sendOk("尊敬的金銀會員，我已經將你傳送至#r金銀會員地圖-鬧鐘之家#n#k了.歡迎再次光臨!"); 
                                   cm.dispose();
                                   }else{
                   cm.sendOk("#b你不是會員2級，請聯繫GM給你在線開通!");
                   cm.dispose();   }     
            } else if (selection == 3) {
            if(cm.getChar().getVip() >= 3) {
                   cm.warp(920010000, 0);
cm.sendOk("尊敬的寶石貴賓，我已經將你傳送至#r寶石貴賓地圖-天空之藍色的天空#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   }else{
                   cm.sendOk("#b你不是會員3級，請聯繫GM給你在線開通!");
                   cm.dispose();   }         
          } else if (selection == 6) {
                   cm.ZreHypvpdeaths();
                   cm.dispose();    
            } else if (selection == 9) {
                   cm.ZreHyzs();
                   cm.dispose();  
            } else if (selection == 10) {
                   cm.displayGuildRanks();
                       cm.dispose();  
            } else if (selection == 11) {
                   cm.sendOk("#b(01)聊天欄裡輸入@help可以打開玩家幫助 \r\n(02)點TRADE可以直接傳送到自由市場。#l \r\n(03)各城市的NaNa說不定會有好東西賣哦!  \r\n(04)海底世界海豚學習騎寵和砸卷技能，VIP2地圖賣新騎寵。 \r\n(05)射手村的寵物管理員Cloy能告訴你關於寵物的一切 \r\n(06)此端由XXX全部提供技術支持!\r\n(07).GM不能隨便改遊戲裡的資料，不如說改遊戲裡的經驗，或者其它遊戲裡的資料，如果發現了第1次給警告處分,第2次以上就取消GM權利!\r\n(08).GM不能隨便丈著自己是GM亂去F別人的號，或者是為了自己個人的利益去送別人GM帽子，這樣是違犯了GM手冊裡的規定發現1次警告並且沒收你的GM和送給別人的帽子，也不能去幫別人去砸武器。\r\n(09).GM有空的話就去給玩家搞活動，玩家需要幫忙的時候要熱心的去幫助玩家，這樣才可以增加玩家對本F的熱愛。\r\n(10).GM有空的時候到處去看看，看有沒有人用G的，有就F了他的號，不能看見了當沒看見，看見的就F號這樣才像一個有責任心的GM。\r\n(11).GM不能隨便在自由市場招怪，要搞活動的時候招，亂召喚的第1次警告2次以上停職1到2天反醒，好好的學習GM手冊。\r\n(12).GM不能隨便把自己的裝備借給玩家用，這樣玩家就不想自己去弄JP武器了了這樣都F的利益也不好，不借東西給玩家好好管F做好自己的本職工作，想玩的人也多了，也會讓F更強大。\r\n(13).GM不用亂去用GM命令這樣F會崩潰的，崩潰以後大家都不能玩，希望GM們不要亂去用GM的命令，GM命令給你們是為了幫助玩家，玩好這個遊戲，讓他們愛上這遊戲，所以該用GM命令的時候就用，不該用的時候就不要用，希望各位GM能去遵守。\r\n(14).#r要求其實也不多希望大家能去遵守著以上的條件。如果不願意做的，還有很多玩家想做GM，希望做了GM的人好好做好工作，珍惜GM的權利!#b\n");
                        cm.dispose();   
            } else if (selection == 13) {
                   cm.ZreHylvl(); 
                   cm.dispose();  
            } else if (selection == 14) {
                   cm.sendOk("#e#rGM清單#k:\r\n1.#b妞B老總\r\n2.#r日本人\r\n3.#g中華盟主\r\n4.#kGM-【黑】\r\n\r\n\r\n                                                                    #g2009.7.10\r\n                                                               妞B管理員隊 ");

                                 cm.dispose();   
      } else if (selection == 15) {
                   cm.ZreHyfame(); 
                   cm.dispose(); 
     } else if (selection == 16) {
                   cm.ZreHymeso(); 
                   cm.dispose(); 
            } else if (selection == 12) {
                   cm.ZreHypvpkills();
                   cm.dispose();   
                } else if (selection == 26) {        
                   cm.sendOk("#e親愛的#r#h ##k,以下是您的信息:\r\n\r\n#rNew#k帳號ID:#r"+cm.getPlayer().getId()+"#k\r\n名字:#r"+cm.getPlayer()+"#k\r\n等級：#r"+cm.getPlayer().getLevel()+"#k\r\n#rNew#k職業:#r"+cm.getPlayer().getJob()+"#k\r\n金錢:#r"+cm.getPlayer().getMeso()+"#k\r\n轉生：#r"+cm.getChar().getReborns()+"#k\r\n屬性點:#r"+cm.getPlayer().getRemainingAp()+"#k\r\n#rNew#k妞幣:#r" +cm.getPlayer().getDonatorPoints()+ "#k\r\n裝備:#r"+(cm.getChar().getInventory(MapleInventoryType.EQUIP).getNextFreeSlot()-1)+"#k\r\n消耗:#r"+(cm.getChar().getInventory(MapleInventoryType.USE).getNextFreeSlot()-1)+"#k\r\n其他:#r"+(cm.getChar().getInventory(MapleInventoryType.ETC).getNextFreeSlot()-1)+"#k\r\n現金:#r"+(cm.getChar().getInventory(MapleInventoryType.CASH).getNextFreeSlot()-1)+"#k\r\n力量:#r"+cm.getPlayer().getStr()+"#k\r\n敏捷:#r"+cm.getPlayer().getDex()+"#k\r\n智力:#r"+cm.getPlayer().getInt()+"#k\r\n運氣:#r"+cm.getPlayer().getLuk()+"#k\r\n#rNew#k今天星期:#r"+(cm.getDayOfWeek()-1)+"#k\r\n#rNew#kVIP等級：#r"+cm.getPlayer().getVip()+"#k\r\n#rNew#k是否組隊:#r"+cm.getPlayer().getParty()+"#k\r\n#rNew#k在這個地圖人數:#r"+cm.getPlayer().getMap().getCharacters().size()+"#k");
                        cm.dispose();           
                        }
                }
        }
}