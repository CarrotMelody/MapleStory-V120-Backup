var status = 0;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1 || status == 4) {
        cm.dispose();
    } else {
        if (status == 2 && mode == 0) {
            cm.sendOk("請需要領取工資再來找我吧！");
            status = 4;
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;
        if (status == 0) {
            cm.sendNext("親愛的#b【 #h #】#k你好，見到你真是太榮幸了，我負責給VIP玩家每天派送工資的，如果確認你是#r VIP玩家 #k請到我這裡來領取工資，否則不要來打擾我！");
        } else if (status == 1) {            
            cm.sendYesNo("#e#b初級VIP每天可以領取1E豬豬幣!#k\r\n#g中級VIP每天可以領取2.5E豬豬幣!#k\r\n#r高級VIP每天可以領取5E豬豬幣!#k\r\n你確定領取今天的工資嗎??#k");
        } else if (status == 2) {
            if(cm.getChar().getVip() == 0) {
            cm.sendOk("對不起！#b 你不是VIP會員 #k無法領取工資。\r\n如需要請聯繫管理員#r QQ：2848268 #k購買VIP會員！");
            } else if (cm.getBossLog('VIPGZ') >= 1) {
            cm.sendOk("抱歉，尊敬VIP玩家你今天己經領取工資，請明天再來找我吧！");
            } else if(cm.getChar().getVip() == 1) {
            cm.gainMeso(100000000);
            cm.setBossLog('VIPGZ');
            cm.sendOk("恭喜你領取今天的工資1E豬豬幣，您真是幸運的玩家");
            } else if(cm.getChar().getVip() == 2) {
            cm.gainMeso(250000000);
            cm.setBossLog('VIPGZ');
            cm.sendOk("恭喜你領取今天的工資2.5E豬豬幣，您真是幸運的玩家");
            } else if(cm.getChar().getVip() == 3) {
            cm.gainMeso(5000000000);
            cm.setBossLog('VIPGZ');
            cm.sendOk("恭喜你領取今天的工資5E豬豬幣，您真是幸運的玩家");
            }
            cm.dispose();
        }
    }    } 