/* 

*/ 

var status = 0; 
var maps = Array(

Array("紅龍",5000031,1000) , 
Array("藍龍",5000032,1000) , 
Array("黑龍 ",5000033,1000) , 
Array("藍龍",5000032,1000) ,
Array("南瓜槍",1432013,10) ,
Array("紅玫瑰",1442048,100) ,
Array("紫玫瑰",1442049,100) ,
Array("淡綠玫瑰",1442050,100) ,
Array("GM帽",1442050,10) ,

); 
var selectedMap = -1; 
function start() { 
status = -1; 
action(1, 0, 0); 
} 
function action(mode, type, selection) { 

if (mode == -1) { 
cm.dispose(); 
} else { 
if (status >= 3 && mode == 0) { 
cm.sendOk("好的,如果你要什麼,我會滿足你的.#r 請趕快考慮吧!低價只限今天喔 #k~"); 
cm.dispose(); 
return; 
} 
if (mode == 1) 
status++; 
else { 
cm.sendOk("好的,如果你要什麼,我會滿足你的."); 
cm.dispose(); 
return; 
} if (status == 0) { 
if(cm.getChar().getName()=="vip3123"){ 
cm.sendYesNo("你是大笨蛋麼?這樣都還不懂!!"); 
cm.dispose(); 
}else{ 

cm.sendYesNo("你好,歡迎來到 #k 柒月冒險島-屬性點交換商店\r\n #r(版權:#e 柒月冒險島 QQ:51218161#k)你想用你的屬性點來換一些東西嗎?#r 慶祝元宵,低價放送! #k你還有#r"+cm.getChar().getRemainingAp()+"#k屬性點!"); 
} 
 cm.serverNotice("『柒月冒險島-屬性點交換商店公告』：哇."+ cm.getChar().getName() +" 玩家打開了柒月冒險島-屬性點交換商店~!難道他需要用屬性點換購本服最稀奇的玩具裝備麼??");
} else if (status == 1) { 
var selStr = "你需要什麼東西呢?速度點喔!快選吧!說不定什麼時候就下架咯,當然也可能會有新東西上架哦.#b"; 
for (var i = 0; i < maps.length; i++) { 
selStr += "\r\n#L" + i + "#" +"#i"+maps[i][1]+"#"+maps[i][0]+"["+maps[i][2]+"點]"; 
} 
selStr +="#k"; 
cm.sendSimple(selStr); 
} else if (status == 2) { 
selectedMap= selection; 
cm.sendYesNo("你真的想要 #b#i" + maps[selection][1] +"#"+ maps[selection][0]+ "#k 嗎?這會花費你#r"+maps[selection][2]+"#k屬性點"); 
 
} 

else if (status == 3) { 
if (cm.getChar().getRemainingAp() < maps[selectedMap][2]) { 
cm.sendOk("八嘎,你找死啊~沒有足夠的屬性點也敢來!讓開.否則告你妨礙公務~."); 
cm.dispose(); 
} else { 
cm.getChar().setRemainingAp (cm.getChar().getRemainingAp() - maps[selectedMap][2]); 
cm.gainItem(maps[selectedMap][1],1); 
var statup = new java.util.ArrayList(); 

statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(cm.getChar().getRemainingAp()))); 
cm.getChar().getClient().getSession().write(net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup)); 

cm.dispose(); 
} 

} 
} 
}