/*
@    Author : Snow
@
@    NPC = NAME
@    Map =  MAP
@    NPC MapId = MAPID
@    Function = Rebirth Player
@
*/

var status = 0;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {

         
         if (mode == -1) {//ExitChat
        cm.dispose();
    
    }else if (mode == 0){//No
        cm.sendOk("�õ�, ���������ȷ����Ҫ #bͶ̥ת��#k.");
        cm.dispose();

    }else{            //Regular Talk
        if (mode == 1)
            status++;
        else
            status--;
        
                 if (status == 0) {
        cm.sendYesNo("��ӭ���װ���#bVIP��Ա#kΰ���Ӣ�ۡ����Ѿ�ͨ��һ��������������ս�ĵ�·�����ڳ�Ϊ�˷�����ӿ�����������ܸ���1�ڽ��. �ҿ������ҵ�Ǭ����Ų���ķ����������Ͷ̥ת���� �����һ�������װ�����ڰ�����! ������Ϊ1���� #b����#k, ����ͬʱ�������е�#b����#k�ջ�.���Ƿ���#rͶ̥ת��#k��?"); 
        }else if (status == 1) {
        if(cm.getChar().getLevel() < 200){
        cm.sendOk("�ܱ�Ǹ������Ҫ200�����ſ���Ͷ̥ת��.");
        cm.dispose();
        }else if (cm.getMeso() < 100000000) {
        cm.sendOk("��û��1�ڽ��,�Ҳ��ܰ����æŶ."); 
        cm.dispose();
        }else{
        cm.sendOk("#b�����÷ǳ���#k, ������ȷ��Ҫ#eͶ̥ת��#n.��");
        }
         }else if (status == 2) {
		wui = 1;
		var statup = new java.util.ArrayList();
		var p = cm.c.getPlayer();
        cm.getChar().levelUp();
        cm.unequipEverything()
        cm.changeJob(net.sf.odinms.client.MapleJob.BEGINNER);
        cm.gainMeso(-100000000);
        cm.sendNext("#b�����÷ǳ���#k, ���Ѿ��ɹ�#eͶ̥ת��#n���˰ɣ���");
	cm.setLevel(2);
		statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LEVEL, java.lang.Integer.valueOf(1)));
		p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
cm.teachSkill(4001002,0,0); 
cm.teachSkill(4001334,0,0); 
cm.teachSkill(4000001,0,0); 
cm.teachSkill(4001344,0,0); 
cm.teachSkill(4000000,0,0); 
cm.teachSkill(4101003,0,0); 
cm.teachSkill(4100000,0,0); 
cm.teachSkill(4100002,0,0); 
cm.teachSkill(4101004,0,0); 
cm.teachSkill(4200000,0,0); 
cm.teachSkill(4200001,0,0); 
cm.teachSkill(4201003,0,0); 
cm.teachSkill(4201002,0,0); 
cm.teachSkill(3000000,0,0); 
cm.teachSkill(3000001,0,0); 
cm.teachSkill(3000002,0,0); 
cm.teachSkill(3001003,0,0); 
cm.teachSkill(3001004,0,0); 
cm.teachSkill(3001005,0,0); 
cm.teachSkill(3200000,0,0); 
cm.teachSkill(3201003,0,0); 
cm.teachSkill(3201002,0,0); 
cm.teachSkill(3201004,0,0); 
cm.teachSkill(3100000,0,0); 
cm.teachSkill(3101002,0,0); 
cm.teachSkill(3101003,0,0); 
cm.teachSkill(3101004,0,0); 
cm.teachSkill(1000000,0,0); 
cm.teachSkill(1000001,0,0); 
cm.teachSkill(1000002,0,0); 
cm.teachSkill(1001003,0,0); 
cm.teachSkill(1001004,0,0); 
cm.teachSkill(1001005,0,0); 
cm.teachSkill(1201005,0,0); 
cm.teachSkill(1201004,0,0); 
cm.teachSkill(1201006,0,0); 
cm.teachSkill(1200000,0,0); 
cm.teachSkill(1101006,0,0); 
cm.teachSkill(1101004,0,0); 
cm.teachSkill(1100000,0,0); 
cm.teachSkill(1100001,0,0); 
cm.teachSkill(1101005,0,0); 
cm.teachSkill(1301006,0,0); 
cm.teachSkill(1301005,0,0); 
cm.teachSkill(1300001,0,0); 
cm.teachSkill(1301004,0,0); 
cm.teachSkill(1300000,0,0); 
cm.teachSkill(2301004,0,0); 
cm.teachSkill(2301003,0,0); 
cm.teachSkill(2300000,0,0); 
cm.teachSkill(2301001,0,0); 
cm.teachSkill(2201001,0,0); 
cm.teachSkill(2200000,0,0); 
cm.teachSkill(2201003,0,0); 
cm.teachSkill(2201002,0,0); 
cm.teachSkill(2101001,0,0); 
cm.teachSkill(2100000,0,0); 
cm.teachSkill(2101003,0,0); 
cm.teachSkill(2101002,0,0); 
cm.teachSkill(2001004,0,0); 
cm.teachSkill(2000001,0,0); 
cm.teachSkill(2000000,0,0); 
cm.teachSkill(2001003,0,0); 
cm.teachSkill(2001005,0,0); 
cm.teachSkill(2001002,0,0); 
cm.teachSkill(4001003,0,0); 
cm.teachSkill(4211005,0,0); 
cm.teachSkill(4211003,0,0); 
cm.teachSkill(4210000,0,0); 
cm.teachSkill(4110000,0,0); 
cm.teachSkill(4111001,0,0); 
cm.teachSkill(4111003,0,0); 
cm.teachSkill(3210000,0,0); 
cm.teachSkill(3110000,0,0); 
cm.teachSkill(3210001,0,0); 
cm.teachSkill(3110001,0,0); 
cm.teachSkill(3211002,0,0); 
cm.teachSkill(3111002,0,0); 
cm.teachSkill(2210000,0,0); 
cm.teachSkill(2211004,0,0); 
cm.teachSkill(2211005,0,0); 
cm.teachSkill(2111005,0,0); 
cm.teachSkill(2111004,0,0); 
cm.teachSkill(2110000,0,0); 
cm.teachSkill(2311001,0,0); 
cm.teachSkill(2311005,0,0); 
cm.teachSkill(2310000,0,0); 
cm.teachSkill(1311007,0,0); 
cm.teachSkill(1310000,0,0); 
cm.teachSkill(1311008,0,0); 
cm.teachSkill(1210001,0,0); 
cm.teachSkill(1211009,0,0); 
cm.teachSkill(1210000,0,0); 
cm.teachSkill(1110001,0,0); 
cm.teachSkill(1111007,0,0); 
cm.teachSkill(1110000,0,0); 
cm.teachSkill(1121000,0,0); 
cm.teachSkill(1221000,0,0); 
cm.teachSkill(1321000,0,0); 
cm.teachSkill(2121000,0,0); 
cm.teachSkill(2221000,0,0); 
cm.teachSkill(2321000,0,0); 
cm.teachSkill(3121000,0,0); 
cm.teachSkill(3221000,0,0); 
cm.teachSkill(4121000,0,0); 
cm.teachSkill(4221000,0,0); 
cm.teachSkill(1321007,0,0); 
cm.teachSkill(1320009,0,0); 
cm.teachSkill(1320008,0,0); 
cm.teachSkill(2321006,0,0); 
cm.teachSkill(1220010,0,0); 
cm.teachSkill(1221004,0,0); 
cm.teachSkill(1221003,0,0); 
cm.teachSkill(1100003,0,0); 
cm.teachSkill(1100002,0,0); 
cm.teachSkill(1101007,0,0); 
cm.teachSkill(1200003,0,0); 
cm.teachSkill(1200002,0,0); 
cm.teachSkill(1201007,0,0); 
cm.teachSkill(1300003,0,0); 
cm.teachSkill(1300002,0,0); 
cm.teachSkill(1301007,0,0); 
cm.teachSkill(2101004,0,0); 
cm.teachSkill(2101005,0,0); 
cm.teachSkill(2201004,0,0); 
cm.teachSkill(2201005,0,0); 
cm.teachSkill(2301002,0,0); 
cm.teachSkill(2301005,0,0); 
cm.teachSkill(3101005,0,0); 
cm.teachSkill(3201005,0,0); 
cm.teachSkill(4100001,0,0); 
cm.teachSkill(4101005,0,0); 
cm.teachSkill(4201005,0,0); 
cm.teachSkill(4201004,0,0); 
cm.teachSkill(1111006,0,0); 
cm.teachSkill(1111005,0,0); 
cm.teachSkill(1111002,0,0); 
cm.teachSkill(1111004,0,0); 
cm.teachSkill(1111003,0,0); 
cm.teachSkill(1111008,0,0); 
cm.teachSkill(1211006,0,0); 
cm.teachSkill(1211002,0,0); 
cm.teachSkill(1211004,0,0); 
cm.teachSkill(1211003,0,0); 
cm.teachSkill(1211005,0,0); 
cm.teachSkill(1211008,0,0); 
cm.teachSkill(1211007,0,0); 
cm.teachSkill(1311004,0,0); 
cm.teachSkill(1311003,0,0); 
cm.teachSkill(1311006,0,0); 
cm.teachSkill(1311002,0,0); 
cm.teachSkill(1311005,0,0); 
cm.teachSkill(1311001,0,0); 
cm.teachSkill(2110001,0,0); 
cm.teachSkill(2111006,0,0); 
cm.teachSkill(2111002,0,0); 
cm.teachSkill(2111003,0,0); 
cm.teachSkill(2210001,0,0); 
cm.teachSkill(2211006,0,0); 
cm.teachSkill(2211002,0,0); 
cm.teachSkill(2211003,0,0); 
cm.teachSkill(2311003,0,0); 
cm.teachSkill(2311002,0,0); 
cm.teachSkill(2311004,0,0); 
cm.teachSkill(2311006,0,0); 
cm.teachSkill(3111004,0,0); 
cm.teachSkill(3111003,0,0); 
cm.teachSkill(3111005,0,0); 
cm.teachSkill(3111006,0,0); 
cm.teachSkill(3211004,0,0); 
cm.teachSkill(3211003,0,0); 
cm.teachSkill(3211005,0,0); 
cm.teachSkill(3211006,0,0); 
cm.teachSkill(4111005,0,0); 
cm.teachSkill(4111006,0,0); 
cm.teachSkill(4111004,0,0); 
cm.teachSkill(4111002,0,0); 
cm.teachSkill(4211002,0,0); 
cm.teachSkill(4211004,0,0); 
cm.teachSkill(4211001,0,0); 
cm.teachSkill(4211006,0,0); 
cm.teachSkill(1120004,0,0); 
cm.teachSkill(1120003,0,0); 
cm.teachSkill(1120005,0,0); 
cm.teachSkill(1121008,0,0); 
cm.teachSkill(1121010,0,0); 
cm.teachSkill(1121001,0,0); 
cm.teachSkill(1121006,0,0); 
cm.teachSkill(1121002,0,0); 
cm.teachSkill(1220005,0,0); 
cm.teachSkill(1221009,0,0); 
cm.teachSkill(1220006,0,0); 
cm.teachSkill(1221001,0,0); 
cm.teachSkill(1221007,0,0); 
cm.teachSkill(1221011,0,0); 
cm.teachSkill(1221002,0,0); 
cm.teachSkill(1320005,0,0); 
cm.teachSkill(1320006,0,0); 
cm.teachSkill(1321001,0,0); 
cm.teachSkill(1321003,0,0); 
cm.teachSkill(1321002,0,0); 
cm.teachSkill(2121005,0,0); 
cm.teachSkill(2121003,0,0); 
cm.teachSkill(2121004,0,0); 
cm.teachSkill(2121002,0,0); 
cm.teachSkill(2121007,0,0); 
cm.teachSkill(2121006,0,0); 
cm.teachSkill(2221007,0,0); 
cm.teachSkill(2221003,0,0); 
cm.teachSkill(2221005,0,0); 
cm.teachSkill(2221004,0,0); 
cm.teachSkill(2221002,0,0); 
cm.teachSkill(2321007,0,0); 
cm.teachSkill(2321003,0,0); 
cm.teachSkill(2321008,0,0); 
cm.teachSkill(2321005,0,0); 
cm.teachSkill(2321004,0,0); 
cm.teachSkill(2321002,0,0); 
cm.teachSkill(3120005,0,0); 
cm.teachSkill(3121008,0,0); 
cm.teachSkill(3121003,0,0); 
cm.teachSkill(3121007,0,0); 
cm.teachSkill(3121006,0,0); 
cm.teachSkill(3121002,0,0); 
cm.teachSkill(3121004,0,0); 
cm.teachSkill(3221006,0,0); 
cm.teachSkill(3220004,0,0); 
cm.teachSkill(3221003,0,0); 
cm.teachSkill(3221005,0,0); 
cm.teachSkill(3221001,0,0); 
cm.teachSkill(3221002,0,0); 
cm.teachSkill(3221007,0,0); 
cm.teachSkill(4121004,0,0); 
cm.teachSkill(4121008,0,0); 
cm.teachSkill(4121003,0,0); 
cm.teachSkill(4121006,0,0); 
cm.teachSkill(4121007,0,0); 
cm.teachSkill(4120005,0,0); 
cm.teachSkill(4221001,0,0); 
cm.teachSkill(4221007,0,0); 
cm.teachSkill(4221004,0,0); 
cm.teachSkill(4221003,0,0); 
cm.teachSkill(4221006,0,0); 
cm.teachSkill(4220005,0,0); 
cm.teachSkill(1121011,0,0); 
cm.teachSkill(1221012,0,0); 
cm.teachSkill(1200001,0,0); 
cm.teachSkill(1321010,0,0); 
cm.teachSkill(2121008,0,0); 
cm.teachSkill(2121001,0,0); 
cm.teachSkill(2221008,0,0); 
cm.teachSkill(2221001,0,0); 
cm.teachSkill(2221006,0,0); 
cm.teachSkill(2321009,0,0); 
cm.teachSkill(2321001,0,0); 
cm.teachSkill(3100001,0,0); 
cm.teachSkill(3121009,0,0); 
cm.teachSkill(3200001,0,0); 
cm.teachSkill(3221008,0,0); 
cm.teachSkill(4121009,0,0); 
cm.teachSkill(4120002,0,0); 
cm.teachSkill(4221008,0,0); 
cm.teachSkill(4220002,0,0); 
        cm.dispose();
        }            
          }
     }