/* 
*活動腳本 
*Final by 颩白勺傳兌 
*/ 
var status = 0; 
  
function start() { 
status = -1; 
action(1, 0, 0); 
} 
  
function action(mode, type, selection) { 
if (mode == -1) { 
cm.dispose(); 
} else { 
if (mode == 0 && status == 0) { 
cm.dispose(); 
return; 
} 
if (mode == 1) 
status++; 
else 
status--; 
if (status == 0) { 
  
cm.sendSimple("#d你好,我是 GM帽 玩具 黑龍項鏈  活動NPC,,我需要請選擇: \r\n#L1# 接受任務 "); 
} else if (status == 1) { 
if (selection == 1) { 
if (cm.haveItem(4000010, 100)) { 
cm.gainItem(4000010, -100); 
cm.gainItem(4031225, 10); 
cm.gainItem(1002140, 1); 
cm.gainItem(1322013, 1); 
cm.gainItem(1042003, 1); 
cm.gainItem(1062007, 1); 
cm.gainItem(1302085, 1); 
cm.gainItem(1302087, 1); 
cm.gainItem(1302084, 1); 
cm.gainItem(1312012, 1); 
cm.gainItem(1312013, 1); 
cm.gainItem(1312014, 1); 
cm.gainItem(1322051, 1); 
cm.gainItem(1322053, 1); 
cm.gainItem(1332021, 1); 
cm.gainItem(1332053, 1); 
cm.gainItem(1402013, 1); 
cm.gainItem(1402014, 1); 
cm.gainItem(1122000, 1); 
cm.gainItem(2041200, 3); 
cm.sendOk("#r真是太感謝你了 幫我找了我心愛的東西！#r 這東西給你 "); 
cm.dispose(); 
} else { 
cm.sendOk("#b由於我偷懶 被呦兒發現 GM要我在這讓玩家做任務#v4000010#你可以幫我找100個回來嗎？任務獎勵#v1002140# #v1322013# #v1042003# #v1062007# #v1302085# #v1302087# #v1302084# #v1312012# #v1312013# #v1312014# #v1322051# #v1322053# #v1332021# #v1332053# #v1402013# #v1402014# #v1122000# #v2041200#"); 
cm.dispose(); 
} 
} else if (selection == 2) { 
if (cm.itemQuantity(4031225) >= 10) { 
if ((cm.haveItem(4005000, 1)) && (cm.haveItem(4005001)) && (cm.haveItem(4005002)) && (cm.haveItem(4005003))) { 
cm.sendOk("#r啊 這麼快就搜集好了這些東西了我真是太感謝你咯 獎勵GM的飛吻吧  開玩笑的這些東西給你！#v1002140# #v1322013# #v1042003# #v1062007# #v1302085# #v1302087# #v1302084# #v1312012# #v1312013# #v1312014# #v1322051# #v1322053# #v1332021# #v1332053# #v1402013# #v1402014# #v1122000# #v2041200#"); 
cm.dispose(); 
} 
  
} else { 
cm.sendOk("你已經幫過我很多了 去休息一會兒吧"); 
mode = 1; 
status = -1; 
} 
} else{ 
cm.sendOk("你沒有完成任務2"); 
mode = 1; 
status = -1; 
} 
} 
} 
} 
