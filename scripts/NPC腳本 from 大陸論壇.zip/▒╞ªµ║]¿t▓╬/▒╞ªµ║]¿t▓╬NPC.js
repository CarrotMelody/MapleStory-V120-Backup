/*
*
* 排行榜系統 NPC    By: ZreHy_MapleStory    網站：www.zrehymxd.cn
*
*/

importPackage(net.sf.odinms.client);

function start() {
	status = -1;
	
	action(1, 0, 0);
}

function action(mode, type, selection) {
            if (mode == -1) {
                cm.dispose();
            }
            else {
                if (status >= 0 && mode == 0) {
                
			cm.sendOk("好的,如果你想好了要做什麼,我會很樂意的為你服務的..");
			cm.dispose();
			return;                    
                }
                if (mode == 1) {
			status++;
		}
		else {
			status--;
		}
		        if (status == 0) {
			cm.sendSimple("迎新年，本服的東西大降價!我是世界導遊小姐(稻、香修復)，為你提供最優質的服務。\r\n #d#L1#會員等級1樂園#l #L2#會員等級2探秘#l #g#L3#會員等級3聖殿#l \r\n\r\n#d#e#L9#【轉生排行榜】#l #L10#家族勢力排行榜#l #g#L16#財富排行#k\r\n\r\n#r#L15#【玩家人氣排行榜】#k #L12#【PK排行榜】#l\r\n\r\n#L13#【等級排行榜】(By:稻、香修復)#l#n #e#b#L6#被殺數排行榜#k#l\r\n\r\n#L14#【本服守則】#l#r #L11#遊戲說明(加了GM手冊)#l  #b");
			} else if (status == 1) {
			if (selection == 1) {
				   if(cm.getChar().getVip() >= 1) {
                   cm.warp(209000000, 0);
                   cm.sendOk("尊敬的VIP1會員，我已經將你傳送至#r會員等級1地圖-幸福村#n#k了.歡迎再次光臨!"); 
				   cm.dispose();
				   }else{
                   cm.sendOk("#b你不是會員1級，請聯繫GM給你在線開通!");
                   cm.dispose();   }  
			} else if  (selection == 2) {
				   if(cm.getChar().getVip() >= 2) {
                   cm.warp(922020300, 0);
cm.sendOk("尊敬的VIP2會員，我已經將你傳送至#r會員等級2地圖-鬧鐘之家#n#k了.歡迎再次光臨!"); 
				   cm.dispose();
				   }else{
                   cm.sendOk("#b你不是會員2級，請聯繫GM給你在線開通!");
                   cm.dispose();   }     
            } else if (selection == 3) {
            if(cm.getChar().getVip() >= 3) {
                   cm.warp(920010000, 0);
cm.sendOk("尊敬的VIP3會員，我已經將你傳送至#r會員等級3地圖-天空之藍色的天空#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   }else{
                   cm.sendOk("#b你不是會員3級，請聯繫GM給你在線開通!");
                   cm.dispose();   }         
          } else if (selection == 6) {
                   cm.ZreHypvpdeaths();
                   cm.dispose();    
            } else if (selection == 9) {
                   cm.ZreHyzs();
                   cm.dispose();  
            } else if (selection == 10) {
                   cm.displayGuildRanks();
	               cm.dispose();  
            } else if (selection == 11) {
                   cm.sendOk("#b(01)聊天欄裡輸入@help可以打開玩家幫助 \r\n(02)點TRADE可以直接傳送到自由市場。#l \r\n(03)各城市的NaNa說不定會有好東西賣哦!  \r\n(04)海底世界海豚學習騎寵和砸卷技能，海底防具店買騎寵。 \r\n(05)射手村的寵物管理員Cloy能告訴你關於寵物的一切 \r\n(06)此端由稻、香全部提供技術支持!\r\n(07).GM不能隨便改遊戲裡的資料，不如說改遊戲裡的經驗，或者其它遊戲裡的資料，如果發現了第1次給警告處分,第2次以上就取消GM權利!\r\n(08).GM不能隨便丈著自己是GM亂去F別人的號，或者是為了自己個人的利益去送被人GM帽子，這樣是違犯了GM手冊裡的規定發現1次警告並且沒收你的GM帽子和送給被人的帽子，也不能去幫別人去砸武器。\r\n(09).GM有空的話就去給玩家搞活動，玩家需要幫忙的時候要熱心的去幫助玩家，這樣才可以增加玩家對本F的熱愛。\r\n(10).GM有空的時候到處去看看，看有沒有人用G的，有就F了他的號，不能看見了當沒看見，看見的就F號著樣才像一個有責任心的GM。\r\n(11).GM不能隨便在自由市場招怪，要搞活動的時候招，亂召喚的第1次警告2次以上停職1到2天反醒，好好的學習GM手冊。\r\n(12).GM不能隨便把自己的裝備借給玩家用，著樣玩家就不想買VIP了這樣都F的利益也不好，不借東西給玩家好好管F做好自己的本職工作，買VIP的人也多了，也會讓F更強大。\r\n(13).GM不用亂去用GM命令這樣F會崩潰的，崩潰以後大家都不能玩，希望GM們不要亂去用GM的命令，GM命令給你們是為了幫助玩家，玩好這個遊戲，讓他們愛上這遊戲，所以該用GM命令的時候就用，不該用的時候就不要用，希望各位GM能去遵守。\r\n(14).#r要求其實也不多希望大家能去遵守著以上的條件。如果不願意做的，還有很多玩家想做GM，希望做了GM的人好好做好工作，珍惜GM的權利!#b\n");
                        cm.dispose();   
            } else if (selection == 13) {
                   cm.ZreHylvl(); 
                   cm.dispose();  
            } else if (selection == 14) {
                   cm.sendOk("請不要使用任何外掛程序,否則封號不給予任何解釋!請GM做好本份工作,見掛即封!一起發揚ZreHy精神! ");

				 cm.dispose();   
      } else if (selection == 15) {
                   cm.ZreHyfame(); 
                   cm.dispose(); 
     } else if (selection == 16) {
                   cm.ZreHymeso(); 
                   cm.dispose(); 
            } else if (selection == 12) {
                   cm.ZreHypvpkills();
                   cm.dispose();   
				
			}
		}
	}
}