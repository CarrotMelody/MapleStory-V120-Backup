/*
小偉製作的一個豪華NPC 希望你喜歡。
 */
var status = 0;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {

    if (mode == -1) {
        cm.dispose();
    } else {
        if (mode == 0) {
            cm.dispose();
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;
        if (status == 0) {
            cm.sendSimple ("#dHI 我#b#g可愛#b的#r【#h #】 #b能為你做點什麼嗎?#b\b\r\n#L0##d超級傳送#b          #d嘿嘿超級牛B哦#v5160007#... ...#b#l\r\n\#l\n#L1##r進入銀行#b          超級VIP專有#v2044303#，#v2044203#，#v2040903#等等#l\r\n#L2#在線轉職          #b找不到轉職師？#v4001007#點這裡吧！#b#l\r\n\#l\n#L3##r屬性增加砸卷次數#b          #v1002140##r記得多加幾次#b\n\#l\r\n#L4##d重置屬性#b          #d可以重加屬性點哦#b#v1602000##l\r\n#L5##g人氣兌換#b          #g10W冒險幣換1人氣#v4000423#便宜吧!#v5200001##l\r\n#L7##d免費滿技能          #v1402017#免費滿技能#b#l\r\n#L8##b清理垃圾#b          清理背包垃圾#v5200002##l\r\n#L9##r百貨商店          #v1402017#眾多百貨任你挑選#b\r\n#L10##r賭博娛樂#b          #v4031138##r記得把內褲藏好，小心輸到沒內褲穿#b	");
        } else if (status == 1) {
            switch(selection) {
                case 0: cm.openNpc(9040010); break;
                case 1: cm.openNpc(9030100); break;
                case 2: cm.openNpc(9030000); break;
                case 3: cm.openNpc(2040042); break;
                case 4: cm.openNpc(2003); break;
                case 5: cm.openNpc(9201025); break;
                case 6: cm.openNpc(9900001); break;
                case 7: cm.openNpc(9201024); break;
                case 8: cm.openNpc(9001006); break;
                case 9: cm.openNpc(9201033); break;
                case 10: cm.openNpc(9000019); break;
            }
        }
    }
}