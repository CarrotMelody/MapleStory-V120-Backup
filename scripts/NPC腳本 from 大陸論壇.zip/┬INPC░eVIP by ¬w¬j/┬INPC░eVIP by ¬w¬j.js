/*
    泡沫端——made by 黑色泡沫V2.0
*/
var status = 0; 
var jobs=new Array("戰士: 力量要求到35點","飛俠: 敏捷要求到25點","法師: 智力要求到25點","弓手:  敏捷要求到25點");

var selectedMap = -1; 

function start() { 
    status = -1; 
    action(1, 0, 0); 
} 

function action(mode, type, selection) { 
    if (mode == -1) { 
        cm.dispose(); 
    } else { 
        if (status >= 3 && mode == 0) { 
            cm.dispose(); 
            return; 
        } 
        if (mode == 1) 
            status++; 
        else { 
            cm.dispose(); 
            return; 
        } if (status == 0) { 
            cm.sendYesNo("你好,我是新手接待員，你要進入泡沫世界嗎？"); 
        } else if (status == 1) { 
            var selStr = "選擇你的職業,系統將送你一套新手裝備和一些錢.#b"; 
                for (var i = 0; i < jobs.length; i++) { 
                selStr += "\r\n#L" + i + "#" + jobs[ i ]+""; 
                } 
            cm.sendSimple(selStr); 
            
        } else if (status == 2) { 
        
        //0-戰士 1-飛俠(1472030,1332025 2-法師(1382009  1002419
            if(selection==0)
            {
                var statup = new java.util.ArrayList();
        var p = cm.c.getPlayer();
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.STR, java.lang.Integer.valueOf(35)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.DEX, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LUK, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.INT, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(p.getRemainingAp())));

        p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
        cm.serverNotice("『泡沫新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在★泡沫世界★裡了,大家熱淚歡迎啊！");
                cm.gainItem(1002140,1);
                cm.getChar().setVip(1);
                cm.setLevel(10);
                cm.warp(102000003,0);
                return;
            }
            if(selection==1)
            {
                var statup = new java.util.ArrayList();
        var p = cm.c.getPlayer();
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.STR, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.DEX, java.lang.Integer.valueOf(25)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LUK, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.INT, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(p.getRemainingAp())));

        p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
        cm.serverNotice("『泡沫公告』：哇."+ cm.getChar().getName() +" 玩家 出生在★泡沫世界★裡了,大家熱淚歡迎啊！");
                  cm.gainItem(1002140,1);
                cm.getChar().setVip(1);
                cm.setLevel(10);
                cm.warp(102000003,0);
                return;
            }
            if(selection==2)
            {
                var statup = new java.util.ArrayList();
        var p = cm.c.getPlayer();
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.STR, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.DEX, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LUK, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.INT, java.lang.Integer.valueOf(25)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(p.getRemainingAp())));

        p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
        cm.serverNotice("『泡沫新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在★泡沫世界★裡了,大家熱淚歡迎啊！");
                cm.gainItem(1002140,1);
                cm.getChar().setVip(1);
                cm.setLevel(10);
                cm.warp(102000003,0);
                      return;
            }
            else
            {
                var statup = new java.util.ArrayList();
        var p = cm.c.getPlayer();
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.STR, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.DEX, java.lang.Integer.valueOf(25)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LUK, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.INT, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(p.getRemainingAp())));

        p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
        cm.serverNotice("『泡沫新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在★泡沫世界★裡了,大家熱淚歡迎啊！");
                 cm.gainItem(1002140,1);
                cm.getChar().setVip(1);
                cm.setLevel(10);
                cm.warp(102000003,0);
                    return;
            }
        } 
        
        
    }
}// JavaScript Document