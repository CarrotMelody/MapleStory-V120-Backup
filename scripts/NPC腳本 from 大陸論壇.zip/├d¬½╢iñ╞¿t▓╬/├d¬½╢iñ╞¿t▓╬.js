//寵物進化NPC
//，筆芯。製作 楓之島

importPackage(net.sf.odinms.client);



var status = 0;
var chance1 = Math.floor(Math.random()*60+1);
var chance2 = Math.floor(Math.random()*50);
var chance3 = (Math.floor(Math.random()*20)+1);
var chance4 = Math.floor(Math.random()*2+1);
var itemchance = chance1 + chance2 + chance3 * chance4;
var itemamount = Math.floor(Math.random()*50+1);


function start() {
	status = -1;
	action(1, 0, 0);
}


function action(mode, type, selection) {
	if (mode == -1) {
		cm.dispose();
	} else {
		if (status >= 2 && mode == 0) {
			cm.sendOk("隨機升級而進化的龍看起來不錯呢~");
			cm.dispose();
			return;
		}
		if (mode == 1)
			status++;
		else
			status--;
		if (status == 0) {
			cm.sendNext("想讓你的寵物龍進化嗎？\r\n\r\n\r\n1、你的寵物必須是#b寶貝龍#k\r\n2、你必須要有一個#b進化之石#k");
			}
		else if (status == 1) {
                        if (cm.haveItem(5380000) && cm.haveItem(5000029)) {
			cm.sendYesNo("你已經符合進化的條件，確定進化嗎？")
			}
			else if (cm.haveItem(5380000)) {
			cm.sendOk("你還沒有達到進化的條件\r\n1、你的寵物必須是#b寶貝龍#k。\r\n2、你必須要有一個#b進化之石#k\r\n\r\n#b[你缺少了 #r寶貝龍#k]#k");
			cm.dispose();
			}
                        else if (cm.haveItem(5000029)) {
			cm.sendOk("你還沒有達到進化的條件\r\n1、你的寵物必須是#b寶貝龍#k。\r\n2、你必須要有一個#b進化之石#k\r\n\r\n#b[你缺少了 #r進化之石#k]#k");
			cm.dispose();
			}
			else
			cm.dispose();
		}
		else if (status == 2) {
			cm.gainItem(5380000, -1);
			cm.gainItem(5000029, -1);

			if ((itemchance >= 1) && (itemchance <= 20)) {
			cm.gainItem(5000030, 1);
			}
			else if ((itemchance >= 21) && (itemchance <= 40)) {
			cm.gainItem(5000031, 1);
			}
			else if ((itemchance >= 41) && (itemchance <= 50)) {
			cm.gainItem(5000032, 1);
			}
			else if ((itemchance >= 51) && (itemchance <= 60)) {
			cm.gainItem(5000033, 1);
			}
			else {
			cm.gainItem(5000031, 1);
			}
            cm.sendOK("隨機升級而進化的龍看起來不錯呢~");
			cm.dispose();
		}
	}
}
