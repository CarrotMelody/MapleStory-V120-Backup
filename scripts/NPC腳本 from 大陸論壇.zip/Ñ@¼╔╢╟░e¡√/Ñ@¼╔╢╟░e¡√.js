/*

市場傳送NPC.活動版本：


論壇:http://btzc.uu1001.com

*/
importPackage(net.sf.odinms.client);

function start() {
    status = -1;
    
    action(1, 0, 0);
}

function action(mode, type, selection) {
            if (mode == -1) {
                cm.dispose();
            }
            else {
                if (status >= 0 && mode == 0) {
                
            cm.sendOk("好的,如果你決定要去哪裡,我會很樂意傳送你的.");
            cm.dispose();
            return;                    
                }
                if (mode == 1) {
            status++;
        }
        else {
            status--;
        }
               if (status == 0) {
            cm.sendSimple("#b我是超級傳送員，請選擇你的目的地：  \r\n#L1#彩虹村#l   \r\n#L2#南港#l    \r\n#L3#明珠港#l  \r\n#L4#射手村#l   \r\n#L5#魔法密林#l    \r\n#L6#黑暗小屋#l     \r\n#L7#勇士部落#l       \r\n#L8#廢棄都市#l     \r\n#L9#諾特勒斯號碼頭#l    \r\n#L10#林中之城#l     \r\n#L11#天空之城#l     \r\n#L12#黃金海岸#l     \r\n#L13#冰峰雪域#l     \r\n#L14#水下世界#l     \r\n#L15#童話村#l     \r\n#L16#玩具城#l     \r\n#L17#東方神州#l     \r\n#L18#武陵#l     \r\n#L19#少林寺#l     \r\n#L20#泰國#l     \r\n#L21#沙漠之城#l     \r\n#L22#不夜城（新）#l     \r\n#L23#新葉城#l     \r\n#L24#神木村#l     \r\n#L25#台灣101大道(新)#l     \r\n#L26#馬加提亞(新)#l     \r\n#L27#楓城(新)#l     \r\n#L28#地球防禦本部#l     \r\n#L29#百草堂#l     \r\n#L30#上海豫園#l     \r\n#L31#吉隆大都市（新）#l     \r\n#L32#聖鵝島（新）#l     \r\n#L33#可口可樂城（新）#l     \r\n#L34#甘榜村（新）#l     \r\n#L35#西門町（新）#l     \r\n#L36#昭和村#l     \r\n#L37#新加坡機場#l     \r\n#L38#新加坡碼頭#l     \r\n#L39#艾林森林（新）#l     \r\n#L40#泰國新地圖（新）#l     \r\n#L41#時間神殿（新）#l     \r\n#L42#古代神社（新）#l     \r\n#L43#夏日競舟（新）#l     \r\n#L44#聖鵝道之岔（新）#l     \r\n#L45#武陵道場入口（新）#l     \r\n#L46#毒霧森林（新）#l     \r\n#L47#古代森林（新）#l     \r\n#L48#森林入口（新）#l     \r\n#L49#網吧 海盜裝備專賣#l     \r\n#L50#英語村#l     \r\n#L51#幸福天堂#l     \r\n#L52#紅鸞宮#l   ");
            } else if (status == 1) {
            if (selection == 1) {
                      cm.warp(1010000, 0);
                  cm.sendOk("我已經將你傳送到#r彩虹村#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                  cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 彩虹村! 請大家共同監督!!");
            } else if  (selection == 2) {
                      cm.warp(60000, 0);
                  cm.sendOk("我已經將你傳送到#r南港#n#k了.歡迎再次光臨!");
                   cm.dispose(); 
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 南港! 請大家共同監督!!");   
            } else if  (selection == 3) {
                      cm.warp(104000000, 0);
                  cm.sendOk("我已經將你傳送到#r明珠港#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 明珠港! 請大家共同監督!!");  
            } else if (selection == 4) {
                      cm.warp(100000000, 0);
                  cm.sendOk("我已經將你傳送到#r射手村#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 射手村! 請大家共同監督!!");  
            } else if (selection == 5) {
                      cm.warp(101000000, 0);
                  cm.sendOk("我已經將你傳送到#r魔法密林#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 魔法密林! 請大家共同監督!!"); 
            } else if (selection == 6) {
                      cm.warp(180000001, 0);
                  cm.sendOk("我已經將你傳送到#r黑暗小屋#n#k了.歡迎再次光臨!");  
                   cm.dispose(); 
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 黑暗小屋! 請大家共同監督!!");
            } else if (selection == 7) {
                      cm.warp(102000000, 0);
                  cm.sendOk("我已經將你傳送到#r勇士部落#n#k了.歡迎再次光臨!"); 
                   cm.dispose();  
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 勇士部落! 請大家共同監督!!");
            } else if (selection == 8) {
                      cm.warp(103000000, 0);
                  cm.sendOk("我已經將你傳送到#r廢棄都市#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 廢棄都市! 請大家共同監督!!");
            } else if (selection == 9) {
                      cm.warp(120000000, 0);
                  cm.sendOk("我已經將你傳送到#r諾特勒斯號碼頭#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 諾特勒斯號碼頭! 請大家共同監督!!");
            } else if (selection == 10) {
                      cm.warp(105040300, 0);
                  cm.sendOk("我已經將你傳送到#r林中之城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 林中之城! 請大家共同監督!!");
                  cm.dispose(); 
            } else if (selection == 11) {
                      cm.warp(200000000, 0);
                  cm.sendOk("我已經將你傳送到#r天空之城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 天空之城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 12) {
                      cm.warp(110000000, 0);
                  cm.sendOk("我已經將你傳送到#r黃金海岸#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 黃金海岸! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 13) {
                      cm.warp(211000000, 0);
                  cm.sendOk("我已經將你傳送到#r冰峰雪域#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 冰峰雪域! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 14) {
                      cm.warp(230000000, 0);
                  cm.sendOk("我已經將你傳送到#r水下世界#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 水下世界! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 15) {
                      cm.warp(222000000, 0);
                  cm.sendOk("我已經將你傳送到#r童話村#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 童話村! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 16) {
                      cm.warp(220000000, 0);
                  cm.sendOk("我已經將你傳送到#r玩具城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 玩具城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 17) {
                      cm.warp(701000000, 0);
                  cm.sendOk("我已經將你傳送到#r東方神州#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 東方神州! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 18) {
                      cm.warp(250000000, 0);
                  cm.sendOk("我已經將你傳送到#r武陵#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 武陵! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 19) {
                      cm.warp(702000000, 0);
                  cm.sendOk("我已經將你傳送到#r少林寺#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 少林寺! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 20) {
                      cm.warp(500000000, 0);
                  cm.sendOk("我已經將你傳送到#r泰國#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 泰國! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 21) {
                      cm.warp(260000000, 0);
                  cm.sendOk("我已經將你傳送到#r沙漠之城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 沙漠之城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 22) {
                      cm.warp(741000000, 0);
                  cm.sendOk("我已經將你傳送到#r不夜城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 不夜城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 23) {
                      cm.warp(600000000, 0);
                  cm.sendOk("我已經將你傳送到#r新葉城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 新葉城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 24) {
                      cm.warp(240000000, 0);
                  cm.sendOk("我已經將你傳送到#r神木村#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 神木村! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 25) {
                      cm.warp(742000000, 0);
                  cm.sendOk("我已經將你傳送到#r台灣101大道#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 台灣101大道! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 26) {
                      cm.warp(261000000, 0);
                  cm.sendOk("我已經將你傳送到#r馬加提亞#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 馬加提亞! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 27) {
                      cm.warp(800040000, 0);
                  cm.sendOk("我已經將你傳送到#r楓城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 楓城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 28) {
                      cm.warp(221000000, 0);
                  cm.sendOk("我已經將你傳送到#r地球防禦本部#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 地球防禦本部! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 29) {
                      cm.warp(251000000, 0);
                  cm.sendOk("我已經將你傳送到#r百草堂#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 百草堂! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 30) {
                      cm.warp(701000200, 0);
                  cm.sendOk("我已經將你傳送到#r上海豫園#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 上海豫園! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 31) {
                      cm.warp(550000000, 0);
                  cm.sendOk("我已經將你傳送到#r吉隆大都市#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 吉隆大都市! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 32) {
                      cm.warp(130000000, 0);
                  cm.sendOk("我已經將你傳送到#r聖鵝島#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 聖鵝島! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 33) {
                      cm.warp(219000000, 0);
                  cm.sendOk("我已經將你傳送到#r可口可樂城#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 可口可樂城! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 34) {
                      cm.warp(551000000, 0);
                  cm.sendOk("我已經將你傳送到#r甘榜村#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 甘榜村! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 35) {
                      cm.warp(740000000, 0);
                  cm.sendOk("我已經將你傳送到#r西門町#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 西門町! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 36) {
                      cm.warp(801000000, 0);
                  cm.sendOk("我已經將你傳送到#r昭和村#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 昭和村! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 37) {
                      cm.warp(540010000, 0);
                  cm.sendOk("我已經將你傳送到#r新加坡機場#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 新加坡機場! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 38) {
                      cm.warp(541000000, 0);
                  cm.sendOk("我已經將你傳送到#r新加坡碼頭#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 新加坡碼頭! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 39) {
                      cm.warp(300000000, 0);
                  cm.sendOk("我已經將你傳送到#r艾林森林#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 艾林森林! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 40) {
                      cm.warp(501000000, 0);
                  cm.sendOk("我已經將你傳送到#r泰國新地圖#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 泰國新地圖! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 41) {
                      cm.warp(270000100, 0);
                  cm.sendOk("我已經將你傳送到#r時間神殿#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 時間神殿! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 42) {
                      cm.warp(800000000, 0);
                  cm.sendOk("我已經將你傳送到#r古代神社#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 古代神社! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 43) {
                      cm.warp(709000101, 0);
                  cm.sendOk("我已經將你傳送到#r夏日競舟#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 夏日競舟! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 44) {
                      cm.warp(130000200, 0);
                  cm.sendOk("我已經將你傳送到#r聖鵝道之岔#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 聖鵝道之岔! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 45) {
                      cm.warp(925020000, 0);
                  cm.sendOk("我已經將你傳送到#r武陵道場入口#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 武陵道場入口! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 46) {
                      cm.warp(930000000, 0);
                  cm.sendOk("我已經將你傳送到#r毒霧森林#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 毒霧森林! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 47) {
                      cm.warp(802000100, 0);
                  cm.sendOk("我已經將你傳送到#r古代森林#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 古代森林! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 48) {
                      cm.warp(930000010, 0);
                  cm.sendOk("我已經將你傳送到#r森林入口#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 森林入口! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 49) {
                      cm.warp(193000000, 0);
                  cm.sendOk("我已經將你傳送到#r網吧 海盜裝備專賣#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 網吧 海盜裝備專賣! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 50) {
                      cm.warp(702090101, 0);
                  cm.sendOk("我已經將你傳送到#r英語村#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 英語村! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 51) {
                      cm.warp(680000000, 0);
                  cm.sendOk("我已經將你傳送到#r幸福天堂#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幸福天堂! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 52) {
                      cm.warp(700000000, 0);
                  cm.sendOk("我已經將你傳送到#r紅鸞宮#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『世界傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 紅鸞宮! 請大家共同監督!!");
                  cm.dispose();           
            }
        }
    }

}var status = 0; 
var maps = Array(1010000,60000,104000000, 100000000, 101000000, 180000001, 102000000, 103000000, 120000000, 105040300,200000000,110000000,211000000,230000000,222000000,220000000,701000000,250000000,702000000,500000000,260000000,741000000,600000000,240000000,742000000,261000000,800040000,221000000,251000000,701000200,550000000,130000000,219000000,551000000,740000000,801000000,540010000,541000000,300000000,501000000,270000100,800000000,709000101,130000200,925020000,930000000,802000100,930000010,193000000,702090101,680000000,700000000, 0); 
