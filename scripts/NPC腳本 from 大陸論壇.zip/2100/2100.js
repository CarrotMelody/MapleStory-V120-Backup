importPackage(net.sf.odinms.client);


var wui = 0;

function start() {
if (cm.getLevel() < 2) {
    cm.sendYesNo ("你好，歡迎您來到冒險世界，我會送你一些禮物，1000W點卷,10E遊戲幣,紀念幣，溫度計，大象，寵物用的物品，GM全套（帽子，皮包，衣服，褲子），5000點屬性。伴隨你度過成長的旅途");
        } else {
            cm.sendOk("不會讓你碰上BUG了吧!");
		cm.gainFame(0);
            cm.dispose();
}
}



function action(mode, type, selection) {
if (cm.getLevel() < 2) {
    if (mode == 0 || wui == 1) {
        cm.dispose();
    } else {
        wui = 1;
        var statup = new java.util.ArrayList();
        var p = cm.c.getPlayer();
        var totAp = p.getRemainingAp() + p.getStr() + p.getDex() + p.getInt() + p.getLuk();
        p.setRemainingAp (totAp -16 +5000);
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.STR, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.DEX, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LUK, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.INT, java.lang.Integer.valueOf(4)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(p.getRemainingAp())));
        p.setStr(4);
        p.setDex(4);
        p.setInt(4);
        p.setLuk(4);
        p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
			cm.gainItem(1002140, 1);//GM帽子
			cm.gainItem(1062007, 1);//GM褲子
			cm.gainItem(1042003, 1);//GM衣服
			cm.gainItem(1322013, 1);//GM皮包
			cm.gainItem(1812005, 1);//寵物望遠鏡
			cm.gainItem(1812000, 1);//寵物吸鐵石
			cm.gainItem(1812001, 1);//寵物金袋
			cm.gainItem(1812004, 1);//寵物速度鞋
			cm.gainItem(5000013, 1);//大象
			cm.gainItem(1402014, 1);//溫度計
			cm.gainItem(4001129, 2);//紀念幣2 
			cm.warp(40000, 0);//送到40000這個地圖
			cm.gainMeso(1000000000);//10E遊戲幣
			cm.gainNX(10000000);//給1000W點卷
        		cm.dispose();
    }
}
}