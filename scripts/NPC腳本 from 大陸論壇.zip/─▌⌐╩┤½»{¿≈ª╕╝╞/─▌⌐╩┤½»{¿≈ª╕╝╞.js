/*
	本MapleStory NPC腳本 版權歸 夜的咖啡 所有
	禁止以任何形式再次分發,甚至銷售
*/


importPackage(java.util);
importPackage(net.sf.odinms.client);
importPackage(net.sf.odinms.server);


var status = 0;
var display;

function start() {
	status = -1;
	action(1, 0, 0);
}

function action(mode, type, selection) {
	if (mode == -1) {
		cm.dispose();
	} else {
		if (mode == 0) {
			cm.dispose();
			return;
		}
		if (mode == 1)
			status++;
		if (status == 0) {
			cm.sendNext("啊哈,是你呀,我認識你麼- -!進入正題拉,我可以幫你把\r\n#r裝備欄第一格#k的物品加1次砸卷次數哦!.");
		} else if (status == 1) {
			cm.sendNext("增加1次砸卷次數需要15點能力點哦\r\n請確認你是否有,並確定裝備欄第一格物品是你要修改的裝備");
		} else if (status == 2) {
			cm.sendYesNo("確定要繼續嗎?");
	    } else if (status == 3) {
			if (cm.getChar().getRemainingAp() < 15) {
				cm.sendOk("抱歉,你還沒有足夠的能力點!");
				cm.dispose();
			}else{
				var item = cm.getChar().getInventory(MapleInventoryType.EQUIP).getItem(1).copy();
				var statup = new java.util.ArrayList();
				cm.getChar().setRemainingAp (cm.getChar().getRemainingAp() - 15);
				statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(cm.getChar().getRemainingAp())));
				cm.getChar().getClient().getSession().write(net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
				
					item.setUpgradeSlots((item.getUpgradeSlots() + 1));
					MapleInventoryManipulator.removeFromSlot(cm.getC(), MapleInventoryType.EQUIP, 1, 1, true);
					MapleInventoryManipulator.addFromDrop(cm.getChar().getClient(), item, "Edit by Coffee");
					
					cm.sendOk("#b恭喜你成功拉!快快看你的包裹吧!#k");
				
				
				cm.dispose();
			}

		}
	}
}