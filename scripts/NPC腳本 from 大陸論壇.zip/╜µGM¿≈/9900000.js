var status = 0;
var choice;
var scrolls = Array(2040300,2040303,2040312,2040403,2040506,2040508,2040507,2040603,2040709,2040710,2040711,2040806,2040807,2040903,2041024,2041025,2043003,2043103,2043203,2043303,2043703,2043803,2044003,2044103,2044203,2044303,2044403,2044503,2044603,2044703);
/*
*  呦兒修改
*/
function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1)
        cm.dispose();
    else {
        if (status == 0 && mode == 0) {
            cm.dispose();
            return;
        } else if (status >= 1 && mode == 0) {
            cm.sendOk("好吧，歡迎下次繼續光臨！.");
            cm.dispose();
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;

        if (status == 0) {
            var choices = "\r\n以下是你可以選擇的購買物品: ";
            for (var i = 0; i < scrolls.length; i++) {
                    choices += "\r\n#L" + i + "##v" + scrolls[i] + "##t" + scrolls[i] + "##l";
            }
            cm.sendSimple("歡迎來到#r貓靈冒險島卷軸商店#k ,你想買我們商店的物品麼？？請選擇吧，每個需要500萬：." + choices);
        } else if (status == 1) {
            cm.sendYesNo("你確定需要購買這個物品麼？這將花費你7000萬金幣！！" +"\r\n#v" + scrolls[selection] + "##t" + scrolls[selection] + "#");
            choice = selection;
        } else if (status == 2) {
            if (cm.getMeso() >= 70000000) {
                cm.gainMeso(-70000000);
                cm.gainItem(scrolls[choice], 1);
                cm.sendOk("謝謝你的光顧，你購買的物品已經放入你的背包！.");
                cm.dispose();
            } else {
                    cm.sendOk("抱歉，你沒足夠的錢！.");
                    cm.dispose();
            }
        }
    }
}