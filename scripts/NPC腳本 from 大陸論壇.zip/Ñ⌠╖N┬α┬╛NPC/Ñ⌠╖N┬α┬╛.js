/* [NPC]
    Job NPC ID 9010009
    Final  by aexr
    @RageZone
*/

importPackage(net.sf.odinms.client);


var status = 0;
var jobName;
var job;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.sendOk("#d好的,如果你改變想法隨時可以告訴我!\r\n#r祝你好運!");
        cm.dispose();
    } else {
        if (mode == 1)
            status++;
        else
            status--;
        if (status == 0) {
cm.sendSimple("這裡可以任意轉職，你想成為：\r\n#r #L1#戰士#l   #L11#魔法師#l   #L21#弓箭手#l   #L28#飛俠#l   #L35#海盜#l \r\n#b #L2#劍客#l   #L5#准騎士#l   #L8#槍戰士#l \r\n#r #L12#火毒法師#l   #L15#冰雷法師#l   #L18#牧師#l \r\n#e #L22#獵人#l   #L25#弩弓手#l \r\n#d #L29#刺客#l   #L32#俠客#l \r\n#g #L36#拳手#l   #L39#火槍手#l \r\n#b #L3#勇士#l   #L6#騎士#l   #L9#龍騎士#l \r\n#r #L13#火毒巫師#l   #L16#冰雷巫師#l   #L19#祭司#l \r\n#e #L23#射手#l   #L26#遊俠#l \r\n#d #L30#無影人#l   #L33#獨行客#l \r\n#g #L37#鬥士#l   #L40#大副#l \r\n#b #L4#英雄#l   #L7#聖騎士#l   #L10#黑騎士#l \r\n#r #L14#火毒魔導士#l   #L17#冰雷魔導士#l   #L20#主教#l \r\n#e #L24#神箭手#l   #L27#箭神#l \r\n#d #L31#隱士#l #L34#俠盜#l \r\n#g #L38#衝鋒隊長#l   #L41#船長#l \r\n#r #L0#新手#l   #L42#管理員#l   #L43#超級管理員#l");


        } else if (status == 1) {
            if (selection == 0) {
                jobName = "新手";
                job = net.sf.odinms.client.MapleJob.BEGINNER;
            }
            if (selection == 1) {
                jobName = "戰士";
                job = net.sf.odinms.client.MapleJob.WARRIOR;
            }
            if (selection == 2) {
                jobName = "劍客";
                job = net.sf.odinms.client.MapleJob.FIGHTER;
            }
            if (selection == 3) {
                jobName = "勇士";
                job = net.sf.odinms.client.MapleJob.CRUSADER;
            }
            if (selection == 4) {
                jobName = "英雄";
                job = net.sf.odinms.client.MapleJob.HERO;
            }
            if (selection == 5) {
                jobName = "准騎士";
                job = net.sf.odinms.client.MapleJob.PAGE;
            }
            if (selection == 6) {
                jobName = "騎士";
                job = net.sf.odinms.client.MapleJob.WHITEKNIGHT;
            }
            if (selection == 7) {
                jobName = "聖騎士";
                job = net.sf.odinms.client.MapleJob.PALADIN;
            }
            if (selection == 8) {
                jobName = "槍戰士";
                job = net.sf.odinms.client.MapleJob.SPEARMAN;
            }
            if (selection == 9) {
                jobName = "龍騎士";
                job = net.sf.odinms.client.MapleJob.DRAGONKNIGHT;
            }
            if (selection == 10) {
                jobName = "黑騎士";
                job = net.sf.odinms.client.MapleJob.DARKKNIGHT;
            }
            if (selection == 11) {
                jobName = "魔法師";
                job = net.sf.odinms.client.MapleJob.MAGICIAN;
            }
            if (selection == 12) {
                jobName = "火毒法師";
                job = net.sf.odinms.client.MapleJob.FP_WIZARD;
            }
            if (selection == 13) {
                jobName = "火毒巫師";
                job = net.sf.odinms.client.MapleJob.FP_MAGE;
            }
            if (selection == 14) {
                jobName = "火毒魔導士";
                job = net.sf.odinms.client.MapleJob.FP_ARCHMAGE;
            }
            if (selection == 15) {
                jobName = "冰雷法師";
                job = net.sf.odinms.client.MapleJob.IL_WIZARD;
            }
            if (selection == 16) {
                jobName = "冰雷巫師";
                job = net.sf.odinms.client.MapleJob.IL_MAGE;
            }
            if (selection == 17) {
                jobName = "冰雷魔導士";
                job = net.sf.odinms.client.MapleJob.IL_ARCHMAGE;
            }
            if (selection == 18) {
                jobName = "牧師";
                job = net.sf.odinms.client.MapleJob.CLERIC;
            }
            if (selection == 19) {
                jobName = "祭司";
                job = net.sf.odinms.client.MapleJob.PRIEST;
            }
            if (selection == 20) {
                jobName = "主教";
                job = net.sf.odinms.client.MapleJob.BISHOP;
            }
            if (selection == 21) {
                jobName = "弓箭手";
                job = net.sf.odinms.client.MapleJob.BOWMAN;
            }
            if (selection == 22) {
                jobName = "獵人";
                job = net.sf.odinms.client.MapleJob.HUNTER;
            }
            if (selection == 23) {
                jobName = "射手";
                job = net.sf.odinms.client.MapleJob.RANGER;
            }
            if (selection == 24) {
                jobName = "神箭手";
                job = net.sf.odinms.client.MapleJob.BOWMASTER;
            }
            if (selection == 25) {
                jobName = "弩弓手";
                job = net.sf.odinms.client.MapleJob.CROSSBOWMAN;
            }
            if (selection == 26) {
                jobName = "遊俠";
                job = net.sf.odinms.client.MapleJob.SNIPER;
            }
            if (selection == 27) {
                jobName = "箭神";
                job = net.sf.odinms.client.MapleJob.MARKSMAN;
            }
            if (selection == 28) {
                jobName = "飛俠";
                job = net.sf.odinms.client.MapleJob.THIEF;
            }
            if (selection == 29) {
                jobName = "刺客";
                job = net.sf.odinms.client.MapleJob.ASSASSIN;
            }
            if (selection == 30) {
                jobName = "無影人";
                job = net.sf.odinms.client.MapleJob.HERMIT;
            }
            if (selection == 31) {
                jobName = "隱士";
                job = net.sf.odinms.client.MapleJob.NIGHTLORD;
            }
            if (selection == 32) {
                jobName = "俠客";
                job = net.sf.odinms.client.MapleJob.BANDIT;
            }
            if (selection == 33) {
                jobName = "獨行客";
                job = net.sf.odinms.client.MapleJob.CHIEFBANDIT;
            }
            if (selection == 34) {
                jobName = "俠盜";
                job = net.sf.odinms.client.MapleJob.SHADOWER;
            }
            if (selection == 35) {
                jobName = "海盜";
                job = net.sf.odinms.client.MapleJob.PIRATE;
            }
            if (selection == 36) {
                jobName = "拳手";
                job = net.sf.odinms.client.MapleJob.BRAWLER;
            }
            if (selection == 37) {
                jobName = "鬥士";
                job = net.sf.odinms.client.MapleJob.MARAUDER;
            }
            if (selection == 38) {
                jobName = "衝鋒隊長";
                job = net.sf.odinms.client.MapleJob.BUCCANEER;
            }
            if (selection == 39) {
                jobName = "火槍手";
                job = net.sf.odinms.client.MapleJob.GUNSLINGER;
            }
            if (selection == 40) {
                jobName = "大副";
                job = net.sf.odinms.client.MapleJob.OUTLAW;
            }
            if (selection == 41) {
                jobName = "船長";
                job = net.sf.odinms.client.MapleJob.CORSAIR;
            }
            if (selection == 42) {
                jobName = "管理員";
                job = net.sf.odinms.client.MapleJob.GM;
            }
            if (selection == 43) {
                jobName = "超級管理員";
                job = net.sf.odinms.client.MapleJob.SUPERGM;
            }
            cm.sendYesNo("#d你想成為: #r[" + jobName + "]#k #d嗎?");
                        
                        
        } else if (status == 2) {
            if (job == net.sf.odinms.client.MapleJob.WARRIOR && cm.c.getPlayer().getStr() < 1) {
                cm.sendOk("#d你沒有符合最小需求: #r[1 力量]#k #d!");
                cm.dispose();
            } else {
                cm.changeJob(job);

                cm.sendOk("#d你去吧,希望你能好好運用,也許不久的未來還能見到你!");
                cm.dispose();
            }
            
          } else {
            cm.dispose();
        }  

    }
}
