/*

市場傳送NPC.活動版本：


論壇:http://btzc.uu1001.com

*/
importPackage(net.sf.odinms.client);

function start() {
    status = -1;
    
    action(1, 0, 0);
}

function action(mode, type, selection) {
            if (mode == -1) {
                cm.dispose();
            }
            else {
                if (status >= 0 && mode == 0) {
                
            cm.sendOk("好的,如果你決定要去哪裡,我會很樂意傳送你的.");
            cm.dispose();
            return;                    
                }
                if (mode == 1) {
            status++;
        }
        else {
            status--;
        }
               if (status == 0) {
            cm.sendSimple("#我能幫你傳送到練級場，請選擇你的目的地：  \r\n#L1#南部森林訓練場Ⅰ#l   \r\n#L2#大木林Ⅰ#l    \r\n#L3#射手訓練場Ⅰ#l  \r\n#L4#地鐵一號線<第1地區>#l   \r\n#L5#地鐵一號線<第4地區>#l    \r\n#L6#第1軍營#l     \r\n#L7#危險的峽谷Ⅱ#l       \r\n#L8#遺跡發掘地Ⅲ#l     \r\n#L9#野豬的領土#l    \r\n#L10#鋼之黑怪之地#l    \r\n#L11#野豬的領土Ⅱ#l    \r\n#L12#豬的海岸#l    \r\n#L13#森林初入#l    \r\n#L14#變質的森林#l    \r\n#L15#螞蟻廣場#l    \r\n#L16#龍穴#l    \r\n#L17#巨人之林#l    \r\n#L18#東海叉路#l    \r\n#L19#西海叉路#l    \r\n#L20#死亡之林Ⅳ#l    \r\n#L21#烏山入口#l    \r\n#L22#時間停止之間#l    \r\n#L23#消失的時間#l    \r\n#L24#時間通道#l    \r\n#L25#露台大廳#l    \r\n#L26#初級修煉場#l    \r\n#L27#十年藥草地#l    \r\n#L28#雲彩公園Ⅲ#l    \r\n#L29#黑暗庭院Ⅰ#l    \r\n#L30#火焰死亡戰場#l    \r\n#L31#龍之巢穴入口#l    \r\n#L32#龍的峽谷#l    \r\n#L33#狼蛛洞穴#l    \r\n#L34#武器庫#l    \r\n#L35#國慶蛋糕地圖#l    \r\n#L36#藏經閣#l    \r\n#L37#未來東京（台場）#l    \r\n#L38#未來東京（機器人社區）#l    \r\n#L39#未來東京（廢墟）#l    \r\n#L40#未來東京（築波研究所）#l    \r\n#L41#未來東京（太空艦隊）#l   ");
            } else if (status == 1) {
            if (selection == 1) {
                      cm.warp(100040001, 0);
                  cm.sendOk("我已經將你傳送到#r南部森林訓練場Ⅰ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                  cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 南部森林訓練場Ⅰ! 請大家共同監督!!");
            } else if  (selection == 2) {
                      cm.warp(101010100, 0);
                  cm.sendOk("我已經將你傳送到#r大木林Ⅰ#n#k了.歡迎再次光臨!");
                   cm.dispose(); 
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 大木林Ⅰ! 請大家共同監督!!");   
            } else if  (selection == 3) {
                      cm.warp(104040000, 0);
                  cm.sendOk("我已經將你傳送到#r射手訓練場Ⅰ#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 射手訓練場Ⅰ! 請大家共同監督!!");  
            } else if (selection == 4) {
                      cm.warp(103000101, 0);
                  cm.sendOk("我已經將你傳送到#r地鐵一號線<第1地區>#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 地鐵一號線<第1地區>! 請大家共同監督!!");  
            } else if (selection == 5) {
                      cm.warp(103000105, 0);
                  cm.sendOk("我已經將你傳送到#r地鐵一號線<第4地區>#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 地鐵一號線<第4地區>! 請大家共同監督!!"); 
            } else if (selection == 6) {
                      cm.warp(101030110, 0);
                  cm.sendOk("我已經將你傳送到#r第1軍營#n#k了.歡迎再次光臨!");  
                   cm.dispose(); 
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 第1軍營! 請大家共同監督!!");
            } else if (selection == 7) {
                      cm.warp(106000002, 0);
                  cm.sendOk("我已經將你傳送到#r危險的峽谷Ⅱ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();  
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 危險的峽谷Ⅱ! 請大家共同監督!!");
            } else if (selection == 8) {
                      cm.warp(101030103, 0);
                  cm.sendOk("我已經將你傳送到#r遺跡發掘地Ⅲ#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 遺跡發掘地Ⅲ! 請大家共同監督!!");
            } else if (selection == 9) {
                      cm.warp(101040001, 0);
                  cm.sendOk("我已經將你傳送到#r野豬的領土#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 野豬的領土! 請大家共同監督!!");
            } else if (selection == 10) {
                      cm.warp(101040003, 0);
                  cm.sendOk("我已經將你傳送到#r鋼之黑怪之地#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 鋼之黑怪之地! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 11) {
                      cm.warp(101030001, 0);
                  cm.sendOk("我已經將你傳送到#r野豬的領土Ⅱ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 野豬的領土Ⅱ! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 12) {
                      cm.warp(104010001, 0);
                  cm.sendOk("我已經將你傳送到#r豬的海岸#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 豬的海岸! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 13) {
                      cm.warp(930000100, 0);
                  cm.sendOk("我已經將你傳送到#r森林初入#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 森林初入! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 14) {
                      cm.warp(930000200, 0);
                  cm.sendOk("我已經將你傳送到#r變質的森林#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 變質的森林! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 15) {
                      cm.warp(105070001, 0);
                  cm.sendOk("我已經將你傳送到#r螞蟻廣場#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 螞蟻廣場! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 16) {
                      cm.warp(105090300, 0);
                  cm.sendOk("我已經將你傳送到#r龍穴#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 龍穴! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 17) {
                      cm.warp(105040306, 0);
                  cm.sendOk("我已經將你傳送到#r巨人之林#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 巨人之林! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 18) {
                      cm.warp(230020000, 0);
                  cm.sendOk("我已經將你傳送到#r東海叉路#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 東海叉路! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 19) {
                      cm.warp(230010400, 0);
                  cm.sendOk("我已經將你傳送到#r西海叉路#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 西海叉路! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 20) {
                      cm.warp(211041400, 0);
                  cm.sendOk("我已經將你傳送到#r死亡之林Ⅳ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 死亡之林Ⅳ! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 21) {
                      cm.warp(222010000, 0);
                  cm.sendOk("我已經將你傳送到#r烏山入口#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 烏山入口! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 22) {
                      cm.warp(220070301, 0);
                  cm.sendOk("我已經將你傳送到#r時間停止之間#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 時間停止之間! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 23) {
                      cm.warp(220070201, 0);
                  cm.sendOk("我已經將你傳送到#r消失的時間#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 消失的時間! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 24) {
                      cm.warp(220050300, 0);
                  cm.sendOk("我已經將你傳送到#r時間通道#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 時間通道! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 25) {
                      cm.warp(220010500, 0);
                  cm.sendOk("我已經將你傳送到#r露台大廳#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 露台大廳! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 26) {
                      cm.warp(250020000, 0);
                  cm.sendOk("我已經將你傳送到#r初級修煉場#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 初級修煉場! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 27) {
                      cm.warp(251010000, 0);
                  cm.sendOk("我已經將你傳送到#r十年藥草地#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 十年藥草地! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 28) {
                      cm.warp(200040000, 0);
                  cm.sendOk("我已經將你傳送到#r雲彩公園Ⅲ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 雲彩公園Ⅲ! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 29) {
                      cm.warp(200010301, 0);
                  cm.sendOk("我已經將你傳送到#r黑暗庭院Ⅰ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 黑暗庭院Ⅰ! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 30) {
                      cm.warp(240020100, 0);
                  cm.sendOk("我已經將你傳送到#r火焰死亡戰場#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 火焰死亡戰場! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 31) {
                      cm.warp(240040500, 0);
                  cm.sendOk("我已經將你傳送到#r龍之巢穴入口#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 龍之巢穴入口! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 32) {
                      cm.warp(240040000, 0);
                  cm.sendOk("我已經將你傳送到#r龍的峽谷#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 龍的峽谷! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 33) {
                      cm.warp(600020300, 0);
                  cm.sendOk("我已經將你傳送到#r狼蛛洞穴#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 狼蛛洞穴! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 34) {
                      cm.warp(801040004, 0);
                  cm.sendOk("我已經將你傳送到#r武器庫#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 武器庫! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 35) {
                      cm.warp(749020000, 0);
                  cm.sendOk("我已經將你傳送到#r國慶蛋糕地圖#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 國慶蛋糕地圖! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 36) {
                      cm.warp(702100000, 0);
                  cm.sendOk("我已經將你傳送到#r藏經閣#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 藏經閣! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 37) {
                      cm.warp(802000200, 0);
                  cm.sendOk("我已經將你傳送到#r未來東京（台場）#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 未來東京（台場）! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 38) {
                      cm.warp(802000300, 0);
                  cm.sendOk("我已經將你傳送到#r未來東京（機器人社區）#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 未來東京（機器人社區）! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 39) {
                      cm.warp(802000400, 0);
                  cm.sendOk("我已經將你傳送到#r未來東京（廢墟）#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 未來東京（廢墟）! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 40) {
                      cm.warp(802000500, 0);
                  cm.sendOk("我已經將你傳送到#r未來東京（築波研究所）#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 未來東京（築波研究所）! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 41) {
                      cm.warp(802000600, 0);
                  cm.sendOk("我已經將你傳送到#r未來東京（太空艦隊）#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『練級傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 未來東京（太空艦隊）! 請大家共同監督!!");
                  cm.dispose();            
            }
        }
    }

}var status = 0; 
var maps = Array(100040001,101010100,104040000,103000101,103000105,101030110,106000002,101030103,101040001,101040003,101030001,104010001,930000100,930000200,105070001,105090300,105040306,230020000,230010400,211041400,222010000,220070301,220070201,220050300,220010500,250020000,251010000,200040000,200010301,240020100,240040500,240040000,600020300,801040004,749020000,702100000,802000200,802000300,802000400,802000500,802000600, 0); 
