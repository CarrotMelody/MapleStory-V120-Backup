/* Sera
    First NPC on Map 0
*/
//By:稻、香  （新人接待員）本創意來自RaGEZONE論壇SmilMS，經過我的改進變成轉職送東西！。.
var wui = 0;

function start() {
    cm.sendSimple (" 你好，#h # 歡迎你來到#rZreHy_MS#k。。我是新人接待員！下面是能為你提供的服務！ \r\n#L0##b超級新人!#k #l\r\n#L1##b弓箭手#k #l\r\n#L2##b魔法師#k #l\r\n#L3##b戰士#k #l\r\n#L4##b飛俠#k #l\r\n#L5##r海盜#k #l");
}

function action(mode, type, selection) {
cm.dispose();
    if (selection == 0) {       
        cm.gainMeso(1000000); 
        cm.gainItem(1082149, 1);
        cm.gainItem(1050018, 1);
        cm.gainItem(1051017, 1);
        cm.gainItem(2022199, 100);
        cm.gainItem(4000138, 1);
        cm.gainItem(1002140, 1);  //gM帽子
        cm.gainItem(1012020, 1);
        cm.gainItem(1072189, 1);
        cm.gainItem(5220000, 10);
        cm.gainItem(5000029, 1);
        cm.gainItem(2040821, 7);
        cm.warp(100000000, 0);
        cm.serverNotice("『新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在ZreHy冒險島世界裡了,大家以後多多關照關照他/她吧！");
        } else if (selection == 1) {
        cm.setLevel(15);
        cm.changeJob(net.sf.odinms.client.MapleJob.BOWMAN);
        cm.gainMeso(1000000); 
        cm.gainItem(1452051, 1);
        cm.gainItem(1002419, 1);
        cm.gainItem(5000003, 1);
        cm.gainItem(2022199, 100);
        cm.gainItem(1072337, 1);
        cm.gainItem(1002140, 1);
        cm.gainItem(1052002, 1);
        cm.gainItem(1012028, 1);
        cm.gainItem(2040807, 7);
        cm.gainItem(1702124, 1);
        cm.gainItem(2044503, 7);
        cm.warp(100000000, 0);
cm.serverNotice("『新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在ZreHy冒險島世界裡了,大家以後多多關照關照他/她吧！");
        } else if (selection == 2) {
        cm.setLevel(15);
                cm.changeJob(net.sf.odinms.client.MapleJob.MAGICIAN);
        cm.gainMeso(1000000); 
        cm.gainItem(1372005, 1);
        cm.gainItem(1002419, 1);
        cm.gainItem(5000003, 1);
        cm.gainItem(2022199, 100);
        cm.gainItem(1072337, 1);
        cm.gainItem(1002140, 1);
        cm.gainItem(1052002, 1);
        cm.gainItem(1012028, 1);
        cm.gainItem(2040817, 7);
        cm.gainItem(1702124, 1);
        cm.gainItem(2043703, 7);
        cm.warp(100000000, 0);
cm.serverNotice("『新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在ZreHy冒險島世界裡了,大家以後多多關照關照他/她吧！");
        } else if (selection == 3) {
        cm.setLevel(15);
        cm.changeJob(net.sf.odinms.client.MapleJob.WARRIOR);
        cm.gainMeso(1000000); 
        cm.gainItem(1302024, 1);
        cm.gainItem(1002419, 1);
        cm.gainItem(5000003, 1);
        cm.gainItem(2022199, 100);
        cm.gainItem(1072337, 1);
        cm.gainItem(1002140, 1);
        cm.gainItem(1052002, 1);
        cm.gainItem(1012028, 1);
        cm.gainItem(2040807, 7);
        cm.gainItem(1702124, 1);
        cm.gainItem(2043003, 7);
        cm.warp(100000000, 0);
cm.serverNotice("『新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在ZreHy冒險島世界裡了,大家以後多多關照關照他/她吧！");
        } else if (selection == 4) {
        cm.setLevel(15)
        cm.changeJob(net.sf.odinms.client.MapleJob.THIEF)
        cm.gainMeso(1000000);  
        cm.gainItem(2043303, 7);        
        cm.gainItem(1002419, 1);
        cm.gainItem(5000003, 1);
        cm.gainItem(2022199, 100);
        cm.gainItem(1072337, 1);
        cm.gainItem(1002140, 1);
        cm.gainItem(1052002, 1);
        cm.gainItem(2040807, 7);
        cm.gainItem(1702124, 1);
cm.gainItem(1002140, 1);
        cm.gainItem(2044703, 7);
        cm.warp(100000000, 0);
cm.serverNotice("『新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在ZreHy冒險島世界裡了,大家以後多多關照關照他/她吧！");
        } else if (selection == 5) {
        cm.setLevel(10);
        cm.changeJob(net.sf.odinms.client.MapleJob.PIRATE);
        cm.gainMeso(1000000); 
        cm.gainItem(1492000, 1);
        cm.gainItem(1492013, 1);
        cm.gainItem(1492004, 1);
        cm.gainItem(2022199, 100);
        cm.gainItem(1002140, 1);
        cm.gainItem(1482022, 1);
        cm.gainItem(1482000, 1);
        cm.gainItem(1482012, 10);
        cm.gainItem(1482023, 1);
        cm.warp(120000000, 0);
cm.serverNotice("『新人公告』：哇."+ cm.getChar().getName() +" 玩家 出生在ZreHy冒險島世界裡了,大家以後多多關照關照他/她吧！");
        cm.dispose();
        }
    if (mode == 0 || wui == 1) {
        cm.dispose();
    } else {
        wui = 1;
        var statup = new java.util.ArrayList();
        var p = cm.c.getPlayer();
        var totAp = p.getRemainingAp() + p.getStr() + p.getDex() + p.getInt() + p.getLuk();
        p.setStr(4);
        p.setDex(4);
        p.setInt(4);
        p.setLuk(4);
        p.setRemainingAp (totAp - 16);
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.STR, java.lang.Integer.valueOf(100)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.DEX, java.lang.Integer.valueOf(100)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LUK, java.lang.Integer.valueOf(100)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.INT, java.lang.Integer.valueOf(100)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLEAP, java.lang.Integer.valueOf(p.getRemainingAp())));

        p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
        cm.sendOk ("來個笑臉吧！！!, #bZreHy_MS_II#k!");
    }
}  
