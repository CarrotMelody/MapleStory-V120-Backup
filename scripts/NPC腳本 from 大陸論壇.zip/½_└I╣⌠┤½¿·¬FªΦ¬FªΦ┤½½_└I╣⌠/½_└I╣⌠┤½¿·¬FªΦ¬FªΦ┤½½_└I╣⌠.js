//Kippieeej for the base of the script, Mikethemak for editing it for this function.
var status = 0;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
    } else {
        if (mode == 0 && status == 0) {
            cm.dispose();
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;
        if (status == 0) {
                cm.sendSimple("Hello #h #, 歡迎來到 #r街舞冒險島#k\r\n黃金級存款銀行，如果你身上的金幣過多可以兌換成等價物品哦\r\n 用你身上的金幣兌換成等價黃金，在您需要的時候我可以給兌換成金幣，不過這可能要收取服務費用，但是已經是很便宜的啦，您要不要兌換\r\n \r\n請先選擇你要兌換的黃金品種，不同品種的黃金可以換到不同數量的金幣，選擇服務前請注意，您包袱裡的錢總共不能超過21E，否則會成負數，再兌換之前您先算算您的錢會不會大於21E，如果成為負數我可不負責哦。嘻嘻 ! ! 兌換後千萬不要雙擊金袋否則會消失! \r\n#L1##b使用15E兌換金袋1個 #v5200002##k#l \r\n \r\n#L2##b使用1個 #v5200002#兌換14.5El#k#l \r\n \r\n#L3#10E冒險幣兌換1個 #v5200001##l \r\n#L4#使用1個 #v5200001# 兌換9.5E冒險幣.#l \r\n#L5#5E冒險幣兌換1個 #v5200000##l \r\n#L6#使用1個 #v5200000# 兌換4.5E冒險幣.#l");
        //cm.dispose();
            } else if (status == 1) {
            if (selection == 1) {
    if (cm.itemQuantity(5200002) >= 50) {
    cm.sendOk(" 你儲存了足夠的 #v5200002# 了, 你不能在存放更多的 #v5200002# 了");
    cm.dispose();
        }  else if (cm.getMeso() >= 1500000000) {
                    cm.gainMeso(-1500000000);                
                    cm.gainItem(5200002, 1); 
                    cm.dispose();
                } else {
                    cm.sendOk("You don't have enough #bMesos#k, are you trying to #eScam#k me!?");
                    cm.dispose();
                }                                
            } else if (selection == 2) {
        if (cm.getMeso() >= 647000000) {
        cm.sendOk("請花掉你身上的錢吧，強行兌換會使你的錢變成負數哦，呵呵");
                cm.dispose();
        } else if (cm.itemQuantity(5200002) >= 1) {
                    cm.gainMeso(1450000000);                
                    cm.gainItem(5200002, -1); 
                    cm.dispose();
                } else {
                    cm.sendOk("你沒有 #v5200002#. 不要想輕易在我這騙到任何東西!");
                    cm.dispose();
                }    
            } else if (selection == 3) {
    if (cm.itemQuantity(5200000) >= 50) {
    cm.sendOk(" 你有足夠多的 #v5200001# 了, 試著兌換一部分 #v5200001# 再來找我兌換銀袋.");
    cm.dispose();
    } else if (cm.getMeso() >= 1000000000) {
                    cm.gainMeso(-1000000000);                
                    cm.gainItem(5200001, 1); 
                    cm.dispose();
                } else {
                    cm.sendOk("You don't have enough #bMesos#k, are you trying to #eScam#k me!?");
                    cm.dispose();
                  }
        } else if (selection == 4) {
        if (cm.getMeso() >= 1147000000) {
        cm.sendOk("請花掉你身上的錢吧，強行兌換會使你的錢變成負數哦，呵呵");
                cm.dispose();
                } else if (cm.itemQuantity(5200001) >= 1) {
                    cm.gainMeso(950000000);                
                    cm.gainItem(5200001, -1); 
                    cm.dispose();
                } else {
                    cm.sendOk("你根本就沒有 #v5200001#. 掙夠錢再來換吧我,這可不是免費服務!");
                    cm.dispose();
              }    
            } else if (selection == 5) {
    if (cm.itemQuantity(5200000) >= 50) {
    cm.sendOk(" 你有足夠多的 #v5200000# 了, 先兌換一部分 #v5200000# 再來找我商量兌換銅幣包的事");
    cm.dispose();
    } else if (cm.getMeso() >= 500000000) {
                    cm.gainMeso(-500000000);                
                    cm.gainItem(5200000, 1); 
                    cm.dispose();
                } else {
                    cm.sendOk("You don't have enough #bMesos#k, are you trying to #eScam#k me!?");
                    cm.dispose();
            }
                } else if (selection == 6) {
        if (cm.getMeso() >= 1647000000) {
        cm.sendOk("請花掉你身上的錢吧，強行兌換會使你的錢變成負數哦，呵呵");
                cm.dispose();
                } else if (cm.itemQuantity(5200000) >= 1) {
                    cm.gainMeso(450000000);                
                    cm.gainItem(5200000, -1); 
                    cm.dispose();
                } else {
                    cm.sendOk("你根本就沒有 #v5200000#. 掙夠錢再來找我兌換吧!.");
                    cm.dispose();
                    }    
                }
            }
        }
    }
