/*

市場傳送NPC.活動版本：


論壇:http://btzc.uu1001.com

*/
importPackage(net.sf.odinms.client);

function start() {
    status = -1;
    
    action(1, 0, 0);
}

function action(mode, type, selection) {
            if (mode == -1) {
                cm.dispose();
            }
            else {
                if (status >= 0 && mode == 0) {
                
            cm.sendOk("好的,如果你決定要去哪裡,我會很樂意傳送你的.");
            cm.dispose();
            return;                    
                }
                if (mode == 1) {
            status++;
        }
        else {
            status--;
        }
               if (status == 0) {
            cm.sendSimple("#bBOSS超級傳送請選擇你的目的地:  \r\n#L1#鐵甲豬公園Ⅲ#l   \r\n#L2#蘑菇王之墓#l    \r\n#L3#藍蘑菇王#l  \r\n#L4#被詛咒的寺院#l   \r\n#L5#幻影森林#l    \r\n#L6#龍族之巢#l     \r\n#L7#格瑞芬多森林#l       \r\n#L8#噴火龍棲息地#l     \r\n#L9#日本御姐#l    \r\n#L10#小型蜈蚣#l    \r\n#L11#輪船船長#l   \r\n#L12#雜交樹精#l   \r\n#L13#鬼騎士#l   \r\n#L14#白色蝙蝠魔#l   \r\n#L15#八爪門神#l   \r\n#L16#石化人#l   \r\n#L17#猴子王#l   \r\n#L18#玩具大熊#l   \r\n#L19#蛇王#l   \r\n#L20#舞獅子#l   \r\n#L21#武林妖僧#l   \r\n#L22#瘋狂小提琴#l   \r\n#L23#黑暗之馬#l   \r\n#L24#黑輪王#l   \r\n#L25#蘑菇抽獎機#l   \r\n#L26#老樹精#l   \r\n#L27#噴火象#l   \r\n#L28#飛天神鳥#l   \r\n#L29#電動大象#l   \r\n#L30#大眼魚#l   \r\n#L31#艾裡斯王座#l   \r\n#L32#皮亞奴斯洞穴#l   \r\n#L33#扎昆入口#l   \r\n#L34#時間塔的本源#l   \r\n#L37#惡夢果#l   \r\n#L38#暗黑龍王洞穴#l   \r\n#L39#幻想森林:殭屍I#l   \r\n#L40#幻想森林:殭屍II#l   \r\n#L41#幻想森林:邪惡的崛起#l   \r\n#L42#幻想森林:扭曲路徑I#l   \r\n#L43#幻想森林:扭曲路徑II#l   \r\n#L44#扭曲路徑III#l   \r\n#L45#幻想森林:扭曲路徑IV#l   \r\n#L46#幻想森林:扭曲路徑V#l   \r\n#L47#大佛的邂逅#l   \r\n#L48#神的黃昏#l  ");
            } else if (status == 1) {
            if (selection == 1) {
                      cm.warp(100000005, 0);
                  cm.sendOk("我已經將你傳送到#r鐵甲豬公園Ⅲ#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                  cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 鐵甲豬公園Ⅲ! 請大家共同監督!!");
            } else if  (selection == 2) {
                      cm.warp(105070002, 0);
                  cm.sendOk("我已經將你傳送到#r蘑菇王之墓#n#k了.歡迎再次光臨!");
                   cm.dispose(); 
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 蘑菇王之墓! 請大家共同監督!!");   
            } else if  (selection == 3) {
                      cm.warp(800010100, 0);
                  cm.sendOk("我已經將你傳送到#r藍蘑菇王#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 藍蘑菇王! 請大家共同監督!!");  
            } else if (selection == 4) {
                      cm.warp(105090900, 0);
                  cm.sendOk("我已經將你傳送到#r被詛咒的寺院#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 被詛咒的寺院! 請大家共同監督!!");  
            } else if (selection == 5) {
                      cm.warp(682000001, 0);
                  cm.sendOk("我已經將你傳送到#r幻影森林#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻影森林! 請大家共同監督!!"); 
            } else if (selection == 6) {
                      cm.warp(105090312, 0);
                  cm.sendOk("我已經將你傳送到#r龍族之巢(#n#k了.歡迎再次光臨!");  
                   cm.dispose(); 
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 龍族之巢! 請大家共同監督!!");
            } else if (selection == 7) {
                      cm.warp(240020101, 0);
                  cm.sendOk("我已經將你傳送到#r格瑞芬多森林#n#k了.歡迎再次光臨!"); 
                   cm.dispose();  
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 格瑞芬多森林! 請大家共同監督!!");
            } else if (selection == 8) {
                      cm.warp(240020401, 0);
                  cm.sendOk("我已經將你傳送到#r噴火龍棲息地#n#k了.歡迎再次光臨!");
                   cm.dispose();  
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 噴火龍棲息地! 請大家共同監督!!");
            } else if (selection == 9) {
                      cm.warp(801040003, 0);
                  cm.sendOk("我已經將你傳送到#r日本御姐#n#k了.歡迎再次光臨!"); 
                   cm.dispose(); 
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 日本御姐! 請大家共同監督!!");
            } else if (selection == 10) {
                      cm.warp(889210600, 0);
                  cm.sendOk("我已經將你傳送到#r小型蜈蚣#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 小型蜈蚣! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 11) {
                      cm.warp(889212500, 0);
                  cm.sendOk("我已經將你傳送到#r輪船船長#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 輪船船長! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 12) {
                      cm.warp(889211800, 0);
                  cm.sendOk("我已經將你傳送到#r雜交樹精#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 雜交樹精! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 13) {
                      cm.warp(889212400, 0);
                  cm.sendOk("我已經將你傳送到#r鬼騎士#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 鬼騎士! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 14) {
                      cm.warp(889212200, 0);
                  cm.sendOk("我已經將你傳送到#r白色蝙蝠魔#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 白色蝙蝠魔! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 15) {
                      cm.warp(889212000, 0);
                  cm.sendOk("我已經將你傳送到#r八爪門神#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 八爪門神! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 16) {
                      cm.warp(889212100, 0);
                  cm.sendOk("我已經將你傳送到#r石化人#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 石化人! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 17) {
                      cm.warp(889211900, 0);
                  cm.sendOk("我已經將你傳送到#r猴子王#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 猴子王! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 18) {
                      cm.warp(889211700, 0);
                  cm.sendOk("我已經將你傳送到#r玩具大熊#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 玩具大熊! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 19) {
                      cm.warp(889211600, 0);
                  cm.sendOk("我已經將你傳送到#r蛇王#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 蛇王! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 20) {
                      cm.warp(889211200, 0);
                  cm.sendOk("我已經將你傳送到#r舞獅子#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 舞獅子! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 21) {
                      cm.warp(889211500, 0);
                  cm.sendOk("我已經將你傳送到#r武林妖僧#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 武林妖僧! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 22) {
                      cm.warp(889211000, 0);
                  cm.sendOk("我已經將你傳送到#r瘋狂小提琴#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 瘋狂小提琴! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 23) {
                      cm.warp(889211100, 0);
                  cm.sendOk("我已經將你傳送到#r黑暗之馬#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 黑暗之馬! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 24) {
                      cm.warp(889210900, 0);
                  cm.sendOk("我已經將你傳送到#r黑輪王#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 黑輪王! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 25) {
                      cm.warp(889210800, 0);
                  cm.sendOk("我已經將你傳送到#r蘑菇抽獎機#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 蘑菇抽獎機! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 26) {
                      cm.warp(889210700, 0);
                  cm.sendOk("我已經將你傳送到#r老樹精#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 老樹精! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 27) {
                      cm.warp(889210500, 0);
                  cm.sendOk("我已經將你傳送到#r噴火象#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 噴火象! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 28) {
                      cm.warp(889210200, 0);
                  cm.sendOk("我已經將你傳送到#r飛天神鳥#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 飛天神鳥! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 29) {
                      cm.warp(889210400, 0);
                  cm.sendOk("我已經將你傳送到#r電動大象#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 電動大象! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 30) {
                      cm.warp(889210300, 0);
                  cm.sendOk("我已經將你傳送到#r大眼魚#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 大眼魚! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 31) {
                      cm.warp(990000900, 0);
                  cm.sendOk("我已經將你傳送到#r艾裡斯王座#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 艾裡斯王座! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 32) {
                      cm.warp(230040420, 0);
                  cm.sendOk("我已經將你傳送到#r皮亞奴斯洞穴#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 皮亞奴斯洞穴! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 33) {
                      cm.warp(211042300, 0);
                  cm.sendOk("我已經將你傳送到#r扎昆入口#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 扎昆入口! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 34) {
                      cm.warp(220080000, 0);
                  cm.sendOk("我已經將你傳送到#r時間塔的本源#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 時間塔的本源! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 37) {
                      cm.warp(801040100, 0);
                  cm.sendOk("我已經將你傳送到#r惡夢果#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 惡夢果! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 38) {
                      cm.warp(240050000, 0);
                  cm.sendOk("我已經將你傳送到#r暗黑龍王洞穴#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 暗黑龍王洞穴! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 39) {
                      cm.warp(610010005, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:殭屍I#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:殭屍I! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 40) {
                      cm.warp(610010013, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:殭屍II#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:殭屍II! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 41) {
                      cm.warp(610010012, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:邪惡的崛起#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:邪惡的崛起! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 42) {
                      cm.warp(610010100, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:扭曲路徑I#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:扭曲路徑I! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 43) {
                      cm.warp(610010101, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:扭曲路徑II#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:扭曲路徑II! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 44) {
                      cm.warp(610010102, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:扭曲路徑III#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 扭曲路徑III! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 45) {
                      cm.warp(610010103, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:扭曲路徑IV#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:扭曲路徑IV! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 46) {
                      cm.warp(610010104, 0);
                  cm.sendOk("我已經將你傳送到#r幻想森林:扭曲路徑V#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 幻想森林:扭曲路徑V! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 47) {
                      cm.warp(800020130, 0);
                  cm.sendOk("我已經將你傳送到#r大佛的邂逅#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 大佛的邂逅! 請大家共同監督!!");
                  cm.dispose();
            } else if (selection == 48) {
                      cm.warp(270050000, 0);
                  cm.sendOk("我已經將你傳送到#r神的黃昏#n#k了.歡迎再次光臨!"); 
                   cm.dispose();
                   cm.serverNotice("『BOSS傳送員公告』：玩家: "+ cm.getChar().getName() +" 使用市場傳送員傳送到 神的黃昏! 請大家共同監督!!");
                  cm.dispose();
            }
        }
    }

}var status = 0; 
var maps = Array(100000005,105070002,800010100, 105090900, 682000001, 105090312, 240020101, 240020401, 230040420, 211042300,889210600,889212500,889211800,889212400,889212200,889212000,889212100,889211900,889211700,889211600,889211200,889211500,889211000,889211100,889210900,889210800,889210700,889210500,889210200,889210400,889210300,990000900,230040420,211042300,220080000,801040100,240050000,610010005,610010013,610010012,610010100,610010101,610010102,610010103,610010104,800020130,270050000, 0); 
