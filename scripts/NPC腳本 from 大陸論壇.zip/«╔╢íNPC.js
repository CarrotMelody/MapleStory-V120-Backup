// Made by king321123 [gil]. 
// Do not release anywhere else FXP or RZ w/out 
// a credit. 

var status = 0; 

function start() { 
status = -1; 
action(1, 0, 0); 
} 

function action(mode, type, selection) { 
    if (mode != 1) { 
        cm.dispose(); 
        return; 
    } else 
        status++; 
    if (status == 0) { 
        cm.sendSimple("額, #b#h ##k. 我可以告訴你一些關於時間的信息. 你想知道什麼內? #b\r\n#L0#現在星期幾?#l\r\n#L1#現在時間.#l#k"); 
    } else if (status == 1) { 
        if (selection == 0) { // Explain about the Holyday. 
            cm.sendOk("現在的 " + cm.getDayOfWeek() + ", 星期是..\r\n\r\n1 - 星期日.\r\n2 - 星期一.\r\n3 - 星期二.\r\n4 - 星期三.\r\n5 - 星期四.\r\n6 - 星期五.\r\n7 - 星期六."); 
    } else if (selection == 1) { // Tells what you have to do. 
        cm.sendNext("現在時間 #r#e" + cm.getHour() + ":" + cm.getMin() + "#k#n. 已經太\r\n晚 or 早.. 我們建議你需要 #b休息.#k"); 
        cm.dispose(); 
} 
} 
}