importPackage(net.sf.odinms.client);

var status = 0;
var fee;
var chance = Math.floor(Math.random()*4+1);

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == -1) {
        cm.dispose();
    } else {
        if (mode == 0) {
            cm.sendOk("很好下次再見");
            cm.dispose();
            return;
        }
        if (mode == 1)
            status++;
        else
            status--;
        if (status == 0) {
            cm.sendNext("嗨。！ #h #! 我是 #b~冒險島賭博機#k!想參與金錢娛樂的遊戲嗎？哈哈 你先下注吧! ");
        } else if (status == 1) {
            cm.sendGetText("你想下注多少金額呢?如果贏了的話可以獲得3倍的收益和GM送的豐厚禮品,呵呵,話不多說啦!快輸入你想要賭博的金額吧,輸了別哭喔!");
        } else if (status == 2) {
            fee = cm.getText();
            cm.sendYesNo("你確定要下注 #r" + fee + "#k 冒險幣嗎?請先檢查你有沒有那麼多錢哦!");
        } else if (status == 3) {
            if (cm.getMeso() < fee) {
                cm.sendOk("哦呵，不好意思你沒那麼多錢了，去賺點錢再來吧，這可不是免費的,快去當掉一些東西再來吧!");
                cm.dispose();
            } else if (cm.getMeso() > 1000000000) {
                cm.sendOk("請先確定包裡的金幣不能超過10億!");
                cm.dispose();
            } else if (cm.getMeso() < 100000) {
                cm.sendOk("對不起,你的金幣不足100000,所以不能參於此次下注!");
                cm.dispose();
            } else if (cm.getText() > 100000000) {
                cm.sendOk("哦不好意思哦!這裡最大賭注不能超過1億!");
                cm.dispose();
            } else if (cm.getText() < 100000) {
                cm.sendOk("虧你想得出來，居然想敲詐，快滾一邊去,找死啊!");
                cm.dispose();
            } else {
                 if (chance <= 1) { 
	                    cm.gainMeso(-fee); 
	                    cm.sendNext("哦··你的運氣不怎麼好哦··哈哈 再來一把嘛!"); 
cm.serverNotice("『賭場公告』：哇.可憐的"+ cm.getChar().getName() +"，在賭場輸的只剩下內褲，他還準備去當掉內褲繼續賭!哎.賭博害人害己害家園啊!"); 
	                    cm.dispose(); 
	                } 
	                else if (chance == 2) { 
	                    cm.gainMeso(-fee); 
	                    cm.sendNext("哦··你的運氣不怎麼好哦··哈哈 再來一把嘛!"); 
                            cm.serverNotice("『賭場公告』：哇.可憐的"+ cm.getChar().getName() +"，在賭場輸的只剩下內褲，他還準備去當掉內褲繼續賭!哎.賭博害人害己害家園啊!"); 
	                    cm.dispose(); 
	                } 
	                else if (chance == 3) { 
	                    cm.gainMeso(-fee); 
	                    cm.sendNext("哦··你的運氣不怎麼好哦··哈哈 再來一把嘛!"); 
                            cm.serverNotice("『賭場公告』：哇.可憐的"+ cm.getChar().getName() +"，在賭場輸的只剩下內褲，他還準備去當掉內褲繼續賭!哎.賭博害人害己害家園啊!"); 
	                    cm.dispose(); 
	                } 
                else if (chance >= 4) {
                    cm.gainMeso(fee * 3);
                    cm.gainItem(2022282,1);
                    cm.gainItem(2022283,1);
                    cm.gainItem(2210010,10);                    
                    cm.sendNext("#r哈哈，恭喜你#k! 你贏了! 獲得3倍的金幣賠償和GM送的豐厚禮品!");
                    cm.serverNotice("『賭場公告』：恭喜"+ cm.getChar().getName() +"，在賭場贏得3倍的金幣和GM送的豐厚禮品，大家一起為他祝賀吧,朋友們.趕快進來繼續賭博!");
                    cm.dispose();
                }
            }
        }
    }
}
