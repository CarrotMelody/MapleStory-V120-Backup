


function start() {
	status = -1;
	
	action(1, 0, 0);
}

function action(mode, type, selection) {
            if (mode == -1) {
                cm.dispose();
            }
            else {
                if (status >= 0 && mode == 0) {
                
			cm.sendOk("感謝你的光臨！");
			cm.dispose();
			return;                    
                }
                if (mode == 1) {
			status++;
		}
		else {
			status--;
		}
		        if (status == 0) {
			cm.sendSimple("您好，歡迎來到蘑菇仔冒險島自動售貨系統\r\n#L1#充值幫助#l \r\n\r\n      #d剩餘點卷#r" + cm.getChar().getNX() + "點\r\n\r\n #L2#初級VIP 300W點卷#l \r\n #L3#高級VIP 500W點卷#l \r\n #L4#超級VIP 800W點卷#l \r\n #L9#VIP升級 300W點卷#l \r\n #L5#轉生憑證 30W點卷#l \r\n #L6#3倍經驗卡 200W點卷#l \r\n #L7#浪人披風(粉) 20W點卷#l \r\n #L8#工地手套(褐) 20W點卷#l");
				} else if (status == 1) {
					if (selection == 1) {
						cm.sendOk("test");
				        cm.dispose();
				}else if  (selection == 2) {
				    if(cm.getChar().getNX() >= 3000000) {
					   cm.gainNX(-3000000);
					   cm.getChar().setVip(1);
					   cm.sendOk("初級VIP購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 3) {
			        if(cm.getChar().getNX() >= 5000000) {
					   cm.gainNX(-5000000);
					   cm.getChar().setVip(2);
					   cm.sendOk("高級VIP購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 4) {
			        if(cm.getChar().getNX() >= 8000000) {
					   cm.gainNX(-8000000);
					   cm.getChar().setVip(3);
					   cm.sendOk("超級VIP購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 5) {
			        if(cm.getChar().getNX() >= 300000) {
					   cm.gainNX(-300000);
					   cm.gainItem(4031692,1);
					   cm.sendOk("轉生憑證購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 6) {
			        if(cm.getChar().getNX() >= 2000000) {
					   cm.gainNX(-2000000);
					   cm.gainItem(5211003,1);
					   cm.sendOk("3倍經驗卡購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 7) {
			        if(cm.getChar().getNX() >= 200000) {
					   cm.gainNX(-200000);
					   cm.gainItem(1102041,1);
					   cm.sendOk("浪人披風(粉)購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 8) {
			        if(cm.getChar().getNX() >= 200000) {
					   cm.gainNX(-200000);
					   cm.gainItem(1082149,1);
					   cm.sendOk("工地手套(褐)購買成功！");
					   cm.dispose();
				    } else {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				    }
			    }else if  (selection == 9) {
			       if(cm.getChar().getVip() >=3 ) {
			           cm.sendOk("你已經是超級VIP了，無需再升級"); 
			           cm.dispose(); 
			   	   }else if (cm.getChar().getNX() < 300000) {
					   cm.sendOk("你沒有足夠的點卷，請充值！"); 
					   cm.dispose(); 
				   } else {
					   cm.gainNX(-300000);
					   cm.getChar().gainVip(1);
					   cm.sendOk("VIP升級成功");
					   cm.dispose();
				   }
				   
			    }
		}
	}
} 