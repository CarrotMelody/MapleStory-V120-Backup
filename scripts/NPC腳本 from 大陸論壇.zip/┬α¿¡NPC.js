/*
@    Author : Snow
@
@    NPC =勇士娜娜轉生NPC
@    Map =  MAP
@    NPC MapId = MAPID
@    Function = Rebirth Player
@
@    想保存技能的話就找到把類似cm.teachSkill(4001002,0,0);這樣的全部刪掉或屏蔽
*/

var status = 0;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {

         
         if (mode == -1) {//ExitChat
        cm.dispose();
    
    }else if (mode == 0){//No
        cm.sendOk("好的, 請告訴我你確定需要 #b投胎轉世#k.");
        cm.dispose();

    }else{            //Regular Talk
        if (mode == 1)
            status++;
        else
            status--;
        
                 if (status == 0) {
        cm.sendYesNo("兄弟,真不敢相信!.. 厲害的#b#h ##k。你已經通過一個漫長而充滿挑戰的道路，終於成為了風起雲湧的人物。如果您能給我2億金幣和#b藍色蝸牛殼#k #v4000000# #r(我旁邊的可樂小姐有換購喔~!)#k。 我可以用我的乾坤大挪移心法，助你進行投胎轉世！ 但是我會清光你的裝備放在包包裡! 您將成為1級的 #b新手#k, 並且同時將您所有的#b技能#k都完整地保留下來，滿JN你可以去找魔法密林的NANA激活所有的技能，你是否想#r轉生#k呢?"); 
        }else if (status == 1) {
        if(cm.getChar().getLevel() < 190){
        cm.sendOk("很抱歉，您需要190級，才可以投胎轉世.");
        cm.dispose();
       }else if (cm.haveItem(4000000) == false){ 
        cm.sendOk("你沒有帶來#b藍色蝸牛殼#k "); 
        cm.dispose(); 
        }else if (cm.getMeso() < 200000000) {
        cm.sendOk("你沒有2億金幣,我不能幫你的忙哦."); 
        cm.dispose();
        }else{
        cm.sendOk("#b您做得非常好#k, 你現在確定要#e投胎轉世#n.嗎？");
        }
        }else if (status == 2) {
		wui = 1;
		var statup = new java.util.ArrayList();
		var p = cm.c.getPlayer();
		//var totAp = p.getRemainingAp() + p.getStr() + p.getDex() + p.getInt() + p.getLuk();
        cm.getChar().setLevel(2);
        cm.unequipEverything()
        cm.changeJob(net.sf.odinms.client.MapleJob.BEGINNER);
        cm.gainMeso(-200000000);
        cm.gainItem(4000000,-1); 
        cm.gainItem(2040506,+10);
        cm.gainItem(1082149,+1);
        cm.gainItem(2040807,+10);
        cm.sendNext("#b您做得非常好#k, 為你成功#e投胎轉世#n高興吧！很佩服你,所以送你一點小禮物~★");
p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));
					cm.serverNotice("『服務器公告』：哇."+ cm.getChar().getName() +" 玩家 轉生冒險島世界裡了,大家一起為他歡呼吧！");
					cm.gainMeso(50000);
        //p.setRemainingAp (totAp - 10);傳承你的屬性總和扣除10點後剩餘的點數
		statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.LEVEL, java.lang.Integer.valueOf(1)));
        statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.EXP, java.lang.Integer.valueOf(0))); 
        //statup.add (new net.sf.odinms.tools.Pair(net.sf.odinms.client.MapleStat.AVAILABLESP, java.lang.Integer.valueOf(p.getRemainingSp())));
		p.getClient().getSession().write (net.sf.odinms.tools.MaplePacketCreator.updatePlayerStats(statup));

        cm.dispose();
        }            
    }
 }
 
    
