//Gachaphon

importPackage(net.sf.odinms.client);



var chance1 = Math.floor(Math.random()*200+1);
var chance2 = Math.floor(Math.random()*50);
var chance3 = (Math.floor(Math.random()*20)+1);
var chance4 = Math.floor(Math.random()*2+1);
var itemchance = chance1 + chance2 + chance3 * chance4;
var itemamount = Math.floor(Math.random()*50+1);


function start() {
	status = -1;
	action(1, 0, 0);
}


function action(mode, type, selection) {
	if (mode == -1) {
		cm.dispose();
	} else {
		if (status >= 2 && mode == 0) {
			cm.sendOk("你的運氣應該是不錯的,下次好運~!");
			cm.dispose();
			return;
		}
		if (mode == 1)
			status++;
		else
			status--;
		if (status == 0) {
				cm.sendNext("我是新八.\r\n如果你有扎頭可以在我這裡抽玩具哦~!\r\n它的形狀是這個樣子的: #v1002357#");
			}
		else if (status == 1) {
			if (cm.haveItem(1002357)) {
			cm.sendYesNo("我看見你有扎頭,你要抽掉它?");
			}
			else if (!cm.haveItem(1002357)) {
			cm.sendOk("你身上沒有扎頭#bGM#k交代我不能幫你!.");
			cm.dispose();
			}
		}
		else if (status == 2) {
			cm.gainItem(1002357, -1);
			if ((itemchance >= 1) && (itemchance <= 20)) {
			cm.gainItem(1002140, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 GM帽!"); 
			}
			else if ((itemchance >= 21) && (itemchance <= 40)) {
			cm.gainItem(1002140, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 GM帽!"); 
			}
                        else if (itemchance == 41) {
			cm.gainItem(1302084, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 火柴 玩具!"); 
			}
                        else if (itemchance == 42) {
			cm.gainItem(1302087, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 火炬 玩具!"); 
			}
                        else if (itemchance == 43) {
			cm.gainItem(1302021, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 橡皮鎯頭 玩具!"); 
			}
                        else if (itemchance == 44) {
			cm.gainItem(1302024, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 廢報紙卷 玩具!"); 
                        }
                        else if (itemchance == 45) {
			cm.gainItem(1302062, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 南瓜劍 玩具!"); 
			}
                        else if (itemchance == 46) {
			cm.gainItem(1302080, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 綵燈鞭子 玩具!"); 
			}
                        else if (itemchance == 47) {
			cm.gainItem(1302095, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 滑水板 玩具!"); 
			}
                        else if (itemchance == 48) {
			cm.gainItem(1302094, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 蝙蝠世家 玩具!"); 
			}
                        else if (itemchance == 49) {
			cm.gainItem(1302101, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 黃色提包 玩具!"); 
			}
                        else if (itemchance == 50) {
			cm.gainItem(1302107, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 白色火刀 玩具!"); 
			}
                        else if (itemchance == 51) {
			cm.gainItem(1302049, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 光線鞭子 玩具!"); 
			}
                        else if (itemchance == 52) {
			cm.gainItem(1302063, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 燃燒火焰刀 玩具!"); 
			}
                        else if (itemchance == 53) {
			cm.gainItem(1302061, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 蔓籐鞭子 玩具!"); 
			}
                        else if (itemchance == 54) {
			cm.gainItem(1312012, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 乾坤圈 玩具!"); 
			}
                        else if (itemchance == 55) {
			cm.gainItem(1312013, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 判官筆 玩具!"); 
			}
                        else if (itemchance == 56) {
			cm.gainItem(1312014, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 閻王筆 玩具!"); 
			}
                        else if (itemchance == 57) {
			cm.gainItem(1312017, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 Chief Axe 玩具!"); 
			}
                        else if (itemchance == 58) {
			cm.gainItem(1322003, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 棒棒果 玩具!"); 
			}
                        else if (itemchance == 59) {
			cm.gainItem(1322027, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 米伽勒的平底鍋 玩具!"); 
			}
                        else if (itemchance == 60) {
			cm.gainItem(1322051, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 七夕 玩具!"); 
			}
                        else if (itemchance == 61) {
			cm.gainItem(1322053, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 金錘 玩具!"); 
			}
                        else if (itemchance == 62) {
			cm.gainItem(1322063, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 白色鴨子 玩具!"); 
			}
                        else if (itemchance == 63) {
			cm.gainItem(1322064, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 黃色鴨子 玩具!"); 
			}
                        else if (itemchance == 64) {
			cm.gainItem(1332020, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 太極扇 玩具!"); 
			}
                        else if (itemchance == 65) {
			cm.gainItem(1332021, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 烏龍茶 玩具!"); 
			}
                        else if (itemchance == 66) {
			cm.gainItem(1332030, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 團扇 玩具!"); 
			}
                        else if (itemchance == 67) {
			cm.gainItem(1332032, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 聖誕樹 玩具!"); 
			}
                        else if (itemchance == 68) {
			cm.gainItem(1332053, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 野外燒烤串 玩具!"); 
			}
                        else if (itemchance == 69) {
			cm.gainItem(1372033, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 聖賢短杖 玩具!"); 
			}
                        else if (itemchance == 70) {
			cm.gainItem(1372017, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 領路燈 玩具!"); 
			}
                        else if (itemchance == 71) {
			cm.gainItem(1402013, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 白日劍 玩具!"); 
			}
                        else if (itemchance == 72) {
			cm.gainItem(1402014, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 溫度計 玩具!"); 
			}
                        else if (itemchance == 73) {
			cm.gainItem(1402044, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 南瓜燈籠 玩具!"); 
			}
                        else if (itemchance == 74) {
			cm.gainItem(1422036, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 玩具匠人的錘子 玩具!"); 
			}
                        else if (itemchance == 75) {
			cm.gainItem(1422011, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 酒瓶 玩具!"); 
			}
                        else if (itemchance == 76) {
			cm.gainItem(1422030, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 粉紅海豹抱枕 玩具!"); 
			}
                        else if (itemchance == 77) {
			cm.gainItem(1422031, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 藍色海豹抱枕 玩具!"); 
			}
                        else if (itemchance == 78) {
			cm.gainItem(1432013, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 南瓜槍 玩具!"); 
			}
                        else if (itemchance == 79) {
			cm.gainItem(1432015, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 紅色滑雪板 玩具!"); 
			}
                        else if (itemchance == 80) {
			cm.gainItem(1432016, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 橙色滑雪板 玩具!"); 
			}
                        else if (itemchance == 81) {
			cm.gainItem(1432017, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 綠色滑雪板 玩具!"); 
			}
                        else if (itemchance == 82) {
			cm.gainItem(1432018, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 藍色滑雪板 玩具!"); 
			}
                        else if (itemchance == 83) {
			cm.gainItem(1432049, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 聖誕槍 玩具!"); 
			}
                        else if (itemchance == 84) {
			cm.gainItem(1432039, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 釣魚竿 玩具!"); 
			}
                        else if (itemchance == 85) {
			cm.gainItem(1442026, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了  紅色衝浪板 玩具!"); 
			}
                        else if (itemchance == 86) {
			cm.gainItem(1442027, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了  綠色衝浪板 玩具!"); 
			}
                        else if (itemchance == 87) {
			cm.gainItem(1442028, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了  藍色衝浪板 玩具!"); 
			}
                        else if (itemchance == 88) {
			cm.gainItem(1442029, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了  紫色衝浪板 玩具!"); 
			}
                        else if (itemchance == 89) {
			cm.gainItem(1442039, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 凍凍魚 玩具!"); 
			}
                        else if (itemchance == 90) {
			cm.gainItem(1442065, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 紅色滑板 玩具!"); 
			}
                        else if (itemchance == 91) {
			cm.gainItem(1442066, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 藍色滑板 玩具!"); 
			}
                        else if (itemchance == 92) {
			cm.gainItem(1442047, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 黃玫瑰 玩具!"); 
			}
                        else if (itemchance == 93) {
			cm.gainItem(1442048, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 紅玫瑰 玩具!"); 
			}
                        else if (itemchance == 94) {
			cm.gainItem(1442049, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 藍玫瑰 玩具!"); 
			}
                        else if (itemchance == 95) {
			cm.gainItem(1442050, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 白玫瑰 玩具!"); 
			}
                        else if (itemchance == 96) {
			cm.gainItem(1442061, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 仙人掌之矛 玩具!"); 
			}
                        else if (itemchance == 97) {
			cm.gainItem(1442054, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 紅色滑水板 玩具!"); 
			}
                        else if (itemchance == 98) {
			cm.gainItem(1442055, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 粉色滑水板 玩具!"); 
			}
                        else if (itemchance == 99) {
			cm.gainItem(1442056, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了藍色滑水板 玩具!"); 
			}
                        else if (itemchance == 100) {
			cm.gainItem(1442057, itemamount);
cm.serverNotice("『活動公告』：恭喜"+ cm.getChar().getName() +"，在抽玩具活動中獲取了 紫色滑水板 玩具!"); 
			}


			cm.dispose();
		}
	}
}
