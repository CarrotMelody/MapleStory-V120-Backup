
var status = 0;

function start() {
	status = -1;
	action(1, 0, 0);
}

function action(mode, type, selection) {
	if (mode == -1 || status == 2) {
		cm.dispose();
	} else {
		if (status == 0 && mode == 0) {
			cm.sendOk("好的,希望以後還可以見到你的!");
			status = 2;
			return;
		}
		if (mode == 1)
			status++;
		else
			status--;
		if (status == 0) {
			cm.sendYesNo("#e歡迎 #h # 來到 #g   #k #r冒險轉生B換購商店,如果你帶來給我2E的話.我可以和你換一個轉生幣的~~!#k.");
		        }else if (status == 1 ) {
		          if (cm.getMeso() >= 200000000) {
                                      cm.sendOk("抱歉,你沒有帶來2E ,我不能換給你轉生B~");
                        cm.dispose();
                        }else{ 
                        cm.sendOk("#b很好#k, 你已成功#e換取#n^_^了.趕快去轉生吧!!"); 
                        } 
                        }else if (status == 2) { 
                        cm.gainMeso(-200000000);
                        cm.gainItem(4001129,+1);
                        cm. sendOk("你已經獲得#v4001129#了!!呵呵,繼續努力吧~!!"); 
                        cm.dispose(); 
                        }            
           
        } 
}  